`*CHALL TEXT*`

In this challenge, we are given a pygame replica of the game snake. In order to complete the challenge, we must submit the correct token to *PLACEHOLDER* in order to get the flag. Let's dive into the source code:

```python
# Import the pygame module
from enum import Enum
import pygame
import base64
# Import pygame.locals for easier access to key coordinates
# Updated to conform to flake8 and black standards
import random
from pygame.locals import (
    RLEACCEL,
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
    K_ESCAPE,
    KEYDOWN,
    QUIT,
)

#Initialize setup for sounds. Defaults are fine. If we want to change defaults we must call this before pygame.init
pygame.mixer.init()
pygame.display.set_caption("Snek")

#Apple made by Kira_Justine20
# Initialize pygame
pygame.init()
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
bounds = (SCREEN_WIDTH,SCREEN_HEIGHT)
window = pygame.display.set_mode(bounds)
#Load and play background music
#Made by bsp7176 from https://freesound.org/people/bsp7176/sounds/570634/
# License: https://creativecommons.org/licenses/by/3.0/
pygame.mixer.music.load("snakeMusic.mp3")
pygame.mixer.music.play(loops=-1)
spaceLevel = pygame.image.load("space.jpg")#Rawdanitsu https://opengameart.org/content/space-backgrounds-1
jungleLevel = pygame.image.load("forest.png")#ramtam https://opengameart.org/content/forest-background-art-2
waterLevel = pygame.image.load("water.png")#Alucard https://opengameart.org/content/2d-background-underwater
victoryImage = pygame.image.load("victory.png")#bevouliin.com https://opengameart.org/content/golden-trophy-game-ornament
backgrounds = []
backgrounds.append(spaceLevel)
backgrounds.append(jungleLevel)
backgrounds.append(waterLevel)
#Load all sound files

snakeMoveSound = pygame.mixer.Sound("snakeMove.mp3") #Sound sources: bsp7176
snakeEatFoodSound = pygame.mixer.Sound("snakeEatFood2.mp3")#aruscio28
snekDeathSound = pygame.mixer.Sound("oof.mp3")#Kayrabey07
victorySound = pygame.mixer.Sound("victorySound.mp3")#Walid

snakeSpeed = 15
def loadSecretTextFileBETA(level):
    try:
        filePointer = open("./secretScoreBETASKIP.txt")
    except Exception as ruhRoh:
        print("File likely not found.")
        return
    secretCode = filePointer.readline()
    # print(secretCode)
    level.verifyLevelCode(secretCode)


class Direction(Enum):
  UP = 0
  DOWN = 1
  LEFT = 2
  RIGHT = 3

class Snake():
    length = None
    direction = None
    body = None
    block_size = None
    color = (0,0,255)
    bounds = None

    def __init__(self, block_size, bounds):
        self.block_size = block_size
        self.bounds = bounds
        self.respawn()
    def respawn(self):
        self.length = 3
        self.body = [(20,20),(20,40),(20,60)]
        self.direction = Direction.RIGHT
    def draw(self, game, window):
        for segment in self.body:
            game.draw.rect(window, self.color, (segment[0],segment[1],self.block_size, self.block_size))
    def move(self):
        current_head = self.body[-1]
        if self.direction == Direction.DOWN:
            next_head = (current_head[0], current_head[1] + self.block_size)
            self.body.append(next_head)
        elif self.direction == Direction.UP:
            next_head = (current_head[0], current_head[1] - self.block_size)
            self.body.append(next_head)
        elif self.direction == Direction.RIGHT:
            next_head = (current_head[0] + self.block_size, current_head[1])
            self.body.append(next_head)
        elif self.direction == Direction.LEFT:
            next_head = (current_head[0] - self.block_size, current_head[1])
            self.body.append(next_head)
        if self.length < len(self.body):
            self.body.pop(0)
    def steer(self, direction):
        if self.direction == Direction.DOWN and direction != Direction.UP:
            self.direction = direction
        elif self.direction == Direction.UP and direction != Direction.DOWN:
            self.direction = direction
        elif self.direction == Direction.LEFT and direction != Direction.RIGHT:
            self.direction = direction
        elif self.direction == Direction.RIGHT and direction != Direction.LEFT:
            self.direction = direction
    def eat(self):
        snakeEatFoodSound.play()
        self.length +=1
    def checkBounds(self):
        head = self.body[-1]
        if head[0] >= self.bounds[0]:
            return True
        if head[1] >= self.bounds[1]:
            return True
        
        if head[0] < 0:
            return True
        if head[1] < 0:
            return True
        return False        

    def checkForFood(self, food):
        head = self.body[-1]
        headTuple = (head[0],head[1])
        foodRect = food.rect
        collide = foodRect.collidepoint(headTuple)
        if(collide):
            self.eat()
            food.respawn()

    def checkTailCollision(self):
        head = self.body[-1]
        hasEatenTail = False

        for i in range(len(self.body) - 1):
            segment = self.body[i]
            if head[0] == segment[0] and head[1] == segment[1]:
                hasEatenTail = True
        return hasEatenTail
class Food(pygame.sprite.Sprite):
    x = 0;
    y = 0;
    def __init__(self):
        super(Food, self).__init__()
        self.surf = pygame.image.load("food.png").convert_alpha()
        self.surf.set_colorkey((255, 255, 255), RLEACCEL)
        self.rect = self.surf.get_rect(center=(random.randint(0, SCREEN_WIDTH),random.randint(0, SCREEN_HEIGHT),))
        self.speed = 0
    def respawn(self):
        self.x = random.randint(0, SCREEN_WIDTH-50)
        self.y = random.randint(0, SCREEN_HEIGHT-50)
        self.rect = self.surf.get_rect(center=(self.x,self.y,))

class Level():
    currentLevel = 0
    snekScore = 0
    levelCode = ""
    def __init__(self, font, window,):
        pass
    def displayCurrentLevel(self,snekLength):
        self.snekScore = snekLength * 10
        text = font.render('Snek Score: ' + str(self.snekScore) + ' Level: ' + str(self.currentLevel), True, (255,255,255))
        window.blit(text, (20,20))
        if self.snekScore >= 100 * self.currentLevel:
            self.levelUP()
    def levelUP(self):
        self.currentLevel = self.currentLevel+1

    def verifyLevelCode(self, levelCode):
        try:
            step1LevelCodeBytes = base64.b64decode(levelCode)
        except Exception as exe:
       	    print("f")
            return False
        step1LevelCode = step1LevelCodeBytes.decode('ascii')
        step2LevelCode = ""
        print(step1LevelCode)
        codeSplit = step1LevelCode.split(":")
        step1LevelCodeFirstPart = codeSplit[0]
        for character in step1LevelCodeFirstPart:
            step2LevelCode += chr(ord(character) - 1)
        print(step2LevelCode)
        if step2LevelCode == "snekGaem1337":
            print("here")
            levelSelector = codeSplit[1]
            try:
                print("made it")
                self.currentLevel = int(levelSelector)
            except Exception as exe:
                return False
        else:
            return False
block_size = 20
snake = Snake(block_size, bounds)
# Create the screen object
# The size is determined by the constant SCREEN_WIDTH and SCREEN_HEIGHT. The function below returns a so called SURFACE which we can draw upon etc.
screen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))#We pass a tuple which is why we have double paranthesis

food = Food()
font = pygame.font.SysFont('comicsans',60, True)
level = Level(font, window)
level.currentLevel = 1
snakeScore = 0
direction = 'right'
#all_sprites are used for rendering
all_sprites = pygame.sprite.Group()
all_sprites.add(food)
loadSecretTextFileBETA(level)
#Keep the main game running
running = True
#Setup the clcok for a decent framerate
clock = pygame.time.Clock()
#Main loop
while running:
    #Look at every event in the event queue
    for event in pygame.event.get():
        #Did the user hit a key?
        if event.type == KEYDOWN:
            #Which key was it? Was it the escape key?
            if event.key == K_ESCAPE:
                running = False#Then we stop the game loop
        #If the event type is QUIT that means the user closed the window.
        elif event.type == QUIT:
            running = False
    window.blit(backgrounds[level.currentLevel % 3],(0,0))
        # Draw entities
    for entity in all_sprites:
        screen.blit(entity.surf, entity.rect)
    pressed_keys = pygame.key.get_pressed()#Load pressed keys and compare against specific keys below. These will determine snek direction.
    if pressed_keys[K_UP]:
            snake.steer(Direction.UP)
            snakeMoveSound.play()
    if pressed_keys[K_DOWN]:
            snake.steer(Direction.DOWN)
            snakeMoveSound.play()
    if pressed_keys[K_LEFT]:
            snake.steer(Direction.LEFT)
            snakeMoveSound.play()
    if pressed_keys[K_RIGHT]:
            snake.steer(Direction.RIGHT)
            snakeMoveSound.play()
    snake.move()
    snake.checkForFood(food)
    level.displayCurrentLevel(snake.length)
    if snake.checkBounds() == True or snake.checkTailCollision() == True:#Did snek leave the screen or did it collide with itself?
        snekDeathSound.play()
        text = font.render('Snek died :((', True, (255,255,255))
        window.blit(text, (20,120))
        pygame.display.update()
        pygame.time.delay(2500)
        level.currentLevel = 1
        snake.respawn()
        food.respawn()
    if level.currentLevel == 99:#This is the win condition but it won't return a flag. 
        window.blit(victoryImage,(120,50))
        text = font.render('SNEK WON. YOU DID IT!', True, (255,255,255))
        victorySound.play()
        window.blit(text, (150,200))
        pygame.display.update()
        pygame.time.delay(2500)
        running = False
    snake.draw(pygame, window)
#The lines below says "Draw surface onto the screen at the center" effectively drawing a surface on the main surface of the game. blit = block transfer
    pygame.display.flip()
    #Ensure program maintains a rate of the snake speed, for intance 30 fps.
    clock.tick(snakeSpeed)
pygame.mixer.music.stop()
pygame.mixer.quit()
```

There is a *lot* of code here, but we quickly see two interesting functions:

```python
def loadSecretTextFileBETA(level):
    try:
        filePointer = open("./secretScoreBETASKIP.txt")
    except Exception as ruhRoh:
        print("File likely not found.")
        return
    secretCode = filePointer.readline()
    # print(secretCode)
    level.verifyLevelCode(secretCode)

class Level():
	...
	def verifyLevelCode(self, levelCode):
        try:
            step1LevelCodeBytes = base64.b64decode(levelCode)
        except Exception as exe:
       	    print("f")
            return False
        step1LevelCode = step1LevelCodeBytes.decode('ascii')
        step2LevelCode = ""
        print(step1LevelCode)
        codeSplit = step1LevelCode.split(":")
        step1LevelCodeFirstPart = codeSplit[0]
        for character in step1LevelCodeFirstPart:
            step2LevelCode += chr(ord(character) - 1)
        print(step2LevelCode)
        if step2LevelCode == "snekGaem1337":
            print("here")
            levelSelector = codeSplit[1]
            try:
                print("made it")
                self.currentLevel = int(levelSelector)
            except Exception as exe:
                return False
        else:
            return False
```

Searching the source code also verifies that these functions do indeed get called. `loadSecretTextFileBETA` is called by the main script, `Food.verifyLevelCode` is called by the former. The first function reads the file `secretScoreBETASKIP.txt`, and then calls the second function with its content. The second executes a number of steps:

- Base64 decodes file contents
- Split the content by ":"
- Decrement the char-value of all characters in first string by one
- Check if the first string equal "snekGaem1337"
- Load the level designated by the second string

Since we know that we have to get to level 99, forging a payload is trivial:

```python
from base64 import b64encode

seg1 = "".join(chr(ord(c) + 1) for c in "snekGaem1337")
seg2 = "99"

skip_code = seg1 + ":" + seg2
skip_code = b64encode(skip_code.encode())

with open("secretScoreBETASKIP.txt", "wb") as f:
	f.write(skip_code)
```

Running this file first, then the game, yields a victory screen. We can now take the base64 encoded string and pass it to the website, to get our flag.