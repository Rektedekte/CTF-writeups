### Description

We are given a link to a website.

>**Proposed difficulty:** Medium-Hard
>
>![Budget GeoGuessr](https://i.imgur.com/eo9yXro.jpg)
>
>[http://exploracao.hkn](http://exploracao.hkn)
>
>_Note: ingen form for bruteforcing er nødvendig for at løse denne opgave_

---

### TLDR

An example page of the i3geo development platforms contains an endpoint `codemirror.php` with local file inclusion. Passing `flag.php` through a filter gives the source code, containing the flag:

>[http://exploracao.hkn/i3geo/exemplos/codemirror.php?pagina=php://filter/convert.base64-encode/resource=../flag.php](http://exploracao.hkn/i3geo/exemplos/codemirror.php?pagina=php://filter/convert.base64-encode/resource=../flag.php)

---

### Writeup

Opening the provided page, we are greeted with a large website. What immediatly stands out, is the link to a page called flag. Clicking it, we are redirected to a webpage, saying that flag is only visible to amin users, bummer. We can assume, that the goal is to request this page.

As the challenge description seems to poke fun of something called i3geo, we can only assume that this is something outside of what the challenge creators have made. That would explain the amount of pages on this website, which is typically not found in ctf challenges. 

A quick google search reveals, that i3geo is a development platform for creating websites. Thinking that it's open source, searching for "i3geo github" gives a link to a github page, presumably containing the development platform used in the challenge:

>[https://github.com/saladesituacao/i3geo](https://github.com/saladesituacao/i3geo)

Checking `versao.php`  confirms this: V. 8.0 alfa. Checking the issue tab of the repository looks promising. There are multiple open vulnerabilities posted by the same user, back in 2022. As the XSS vulnerabilities seem irrelevant, we instead check the LFI vulnerability.

This issue details an unrestricted Local File Inclusion on the `/exemplos/codemirror.php` endpoint. In this case, `codemirror.php` simply includes any file specified in the `pagina` parameter.

We could try to exploit this, by seeing if any logs are available for an easy log poisoning, but as we know that the flag should be pressent in `flag.php`, there would be no need. Jumping back a folder to `flag.php` should work:

>[http://exploracao.hkn/i3geo/exemplos/codemirror.php?pagina=../flag.php](http://exploracao.hkn/i3geo/exemplos/codemirror.php?pagina=../flag.php)

This would not work however, as php include would execute the code, leading to the exact same page as before. A quick google search reveals a solution: php filters. Essentially, before interpreting the included file, php can apply a filter, such as base64 encoding. Modifying the url to the following:

>[http://exploracao.hkn/i3geo/exemplos/codemirror.php?pagina=php://filter/convert.base64-encode/resource=../flag.php](http://exploracao.hkn/i3geo/exemplos/codemirror.php?pagina=php://filter/convert.base64-encode/resource=../flag.php)

Using this request yields a base64 string. Decoding it, we can see that it contains the flag:

>DDC{1nclu54o_d3_4rqu1v0_l0c4l}