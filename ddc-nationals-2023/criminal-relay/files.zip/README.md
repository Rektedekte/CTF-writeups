### Description

We are given a netcat port and the source code for the service behind it.

>**Proposed Difficulty:** Medium
>
>Vi fandt en server, som modtager beskeder og derefter krypterer dem med modtagerens identitet, før de videresendes gennem dark web til mixnetværket.
>
>Kan du finde modtageren?
>
>[challenge.py](https://nextcloud.ntp-event.dk:8443/s/ZaobcJFEG2gm7iN/download/challenge.py)
>
>`nc criminalrelay.hkn 80`

---

### Recon

Jumping into the code, we find a service that continuously compresses and encrypts messages together with the flag, before sending it off to the dARk WeB. Most interesting is the function for encrypting the message:

```python
def encrypt_and_send(msg):
    msg_struct = f'MSG: {msg} TO: ____{flag}____ '
    encoded_message = zlib.compress(msg_struct.encode())
    cipher = AES.new(key, AES.MODE_CTR)
    ct = cipher.nonce + cipher.encrypt(encoded_message)
    # send through super tor mixnet jump server darkweb thingy TOR process xd
    print(f'We intercepted the following message leaving the relay node: {ct.hex()}')
```

The most interesting element is the use of zlib compression. In short, zlib compression, aside from also encoding the data, replaces duplicate occurences of the same string with so-called back-references. This saves on length, because long sequences can be replaced by compact references. 

---

### ZLIB oracle

We can experiment in a shell to see how it affects output size:

```python
>>> len(zlib.compress(b"test-data-with-no-long-repeats-1234567"))
46
>>> len(zlib.compress(b"test-data-with-no-long-repeats-repeats"))
39
```

As we can see, repeating the same sequence saves a whole 7 bytes from the output size. Additionally, because of these back-references, appending more data from an already present string will not affect size, because zlib simply references back to the existing string:

```python
>>> len(zlib.compress(b"MSG: some to ____some-string____"))
34
>>> len(zlib.compress(b"MSG: some- to ____some-string____"))
34
>>> len(zlib.compress(b"MSG: some-s to ____some-string____"))
34
>>> len(zlib.compress(b"MSG: some-st to ____some-string____"))
34
...
```

Combine this with the use of AES-CTR, which doesn't require data to be padded to 16 bytes, and we effectively have an oracle, that reveals whether a guessed character of the flag is correct, based on whether the output size changes or not.

---

### Solution

The following solve script is based on the oracle described above. It starts with the known flag text "DDC{", and then tests each character in the charset, to see if it's correct.

```python
from pwn import *

def get_length(msg):
	conn.recvuntil(b": ")
	conn.sendline(msg.encode())
	
	conn.recvuntil(b"node: ")
	resp = conn.recvline()[:-1]
	return len(resp)

conn = connect("criminalrelay.hkn", 80)

flag = "DDC{"
charset = 'abcdefghijklmnopqrstuvwxyz_}'

while not flag.endswith("}"):
	curr = get_length(flag)

	for char in charset:
		new_flag = flag + char
		
		if get_length(new_flag) == curr:
			flag = flag + char
			break

print(flag)
```