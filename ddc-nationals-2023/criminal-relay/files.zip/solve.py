from pwn import *

def get_length(msg):
	conn.recvuntil(b": ")
	conn.sendline(msg.encode())
	
	conn.recvuntil(b"node: ")
	resp = conn.recvline()[:-1]
	return len(resp)

conn = connect("criminalrelay.hkn", 80)

flag = "DDC{"
charset = 'abcdefghijklmnopqrstuvwxyz_}'

while not flag.endswith("}"):
	curr = get_length(flag)

	for char in charset:
		new_flag = flag + char
		
		if get_length(new_flag) == curr:
			flag = flag + char
			break

print(flag)
