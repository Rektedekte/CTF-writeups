from Crypto.Util.number import bytes_to_long
from hashlib import sha256
import os

from pwn import *
import string


def H(s):
    return int(sha256(s.encode()).hexdigest(), 16)


def sign_message(msg):
    while True:
        # Choose random nonce and check signature validity
        k = bytes_to_long(os.urandom(2))
        r = pow(g, k, p) % q
        s = (pow(k, -1, q) * (H(msg) + x * r)) % q
        if r > 1 and s > 0:
            return r, s


def generate_signature(msg):
	conn.recvuntil(b">")
	conn.sendline(b"1")
	
	conn.recvuntil(b">")
	conn.sendline(msg.encode())
	
	conn.recvuntil(b"Signature:")
	sig = conn.recvline()[:-1].decode()
	sig = sig.replace("(", "").replace(")", "")
	r, s = sig.split(", ")
	
	r = int(r)
	s = int(s)
	
	return r, s


def crack(r, s1, s2, msg1, msg2):
	k = (H(msg1) - H(msg2)) * pow(s1 - s2, -1, q) % q  # Calculate k from two signatures
	x = (s1 * k % q - H(msg1)) * pow(r, -1, q) % q  # Calculate private x from k and signature
	
	return k, x


# conn = process(["python3", "server.py"])
conn = connect("dsa.hkn", 1337)

conn.recvuntil(b"(p, q, g, y) = ")
params = conn.recvline()[:-1].decode()
params = params.replace("(", "").replace(")", "")
p, q, g, y = (int(v) for v in params.split(", "))

sigs = {}

while True:  # Generate signatures until we have a collision
	msg = "".join(random.sample(string.ascii_lowercase, 5))  # Random message so signatures are different
	r, s = generate_signature(msg)

	if r in sigs:  # Check if we have a collision
		break
		
	sigs[r] = (s, msg)


k, x = crack(r, sigs[r][0], s, sigs[r][1], msg)  # Calculate k and x
r, s = sign_message("CONFIDENTIAL")  # Forge signature for CONFIDENTIAL

conn.recvuntil(b">")
conn.sendline(b"2")

conn.recvuntil(b">")
conn.sendline(b"CONFIDENTIAL")

conn.recvuntil(b">")
conn.sendline(f"({r}, {s})".encode())  # Verify the forged signature

conn.interactive()
