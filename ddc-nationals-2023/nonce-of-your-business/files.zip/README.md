### Description

We are given a netcat port and the source code for the service behind it.

>**Proposed Difficulty:** Easy-Medium
>
>Vi har kompromitteret Digital Secret Agency's mission server og skaffet adgang til source koden. Agenturet bruger serveren til at signere nye missioner til deres agenter, der selv kan verificere disse i marken.
>
>Vi har spottet, at agenter på `CONFIDENTIAL` missioner får udleveret et hemmeligt kodeord under verificeringen. Kan du skaffe os dette?
>
>`nc dsa.hkn 1337`
>
>[server.py](https://nextcloud.ntp-event.dk:8443/s/TWeMR23DFpJWBww/download/server.py)

---

### Recon

Checking the source, we find a simple DSA signature service. The service provides two options: sign mission statement and verify mission statement. Checking the code for verifying a signature first:

```python
        elif choice == "2":
            msg = get_input("Enter mission statement to verify")
            signature = get_input("Enter received signature (r,s)").replace("(", "").replace(")", "").split(",")
            try:
                r = int(signature[0])
                s = int(signature[1])
            except:
                print("Invalid signature format\n")
                continue

            valid = verify_message(msg, r, s)
            if valid:
                print("Mission statement verified")

                # Give agents needed codeword for confidential missions
                if msg.startswith("CONFIDENTIAL"):
                    print(f"Codeword: {flag}")

                print("Good luck, agent!\n")
            else:
                print("Invalid signature! Be careful, agent!\n")
```

As we can see, the goal is to get a valid signature for a message starting with "CONFIDENTIAL". However:

```python
        if choice == "1":
            msg = get_input("Enter mission statement")
            if msg.startswith("CONFIDENTIAL"):
                print("Only leaders with a high security clearance can sign CONFIDENTIAL mission statements.")
                user_codeword = get_input("Verify your clearance with your secret codeword")
                if user_codeword != codeword:
                    print("This incidence has been logged, expect a visit soon\n")
                    continue
                print("Codeword verified, mission safe to sign\n")

            signature = sign_message(msg)
            print(f"Signature: {signature}\n")
```

The service won't allow us to sign a confidential message, without providing the correct codeword. Just so happens, that the codeword is referenced nowhere else in the program, so we most likely can't obtain it. Let's check the code for signing a message:

```python
def sign_message(msg):
    while True:
        # Choose random nonce and check signature validity
        k = bytes_to_long(os.urandom(2))
        r = pow(g, k, p) % q
        s = (pow(k, -1, q) * (H(msg) + x * r)) % q
        if r > 1 and s > 0:
            return r, s
```

Standard DSA stuff, select a random nonce k, calculate r and s from that. However, the code for selecting a nonce is quite odd. Usually, you would select a random number between $1$ and $q - 1$, but in this case, it uses two bytes of urandom to generate the nonce. That gives a total of $256^2=65536$ possible nonces. That is small enough to encounter collisions, where two signatures use the same nonce. In that case, r will be the same, as it doesn't depend on the message. Therefore, we can easily both generate and identify collisions.

---

### Breaking DSA

Suppose we have two signatures, both generated from the same nonce, but different messages. We would calculate s by:

$$s_1=modinv(k, q)\cdot(H(msg_1)+x\cdot r)\mod{q}$$
$$s_2=modinv(k, q)\cdot(H(msg_2)+x\cdot r)\mod{q}$$

Notably, when the nonce is reused, we effectively have two equations with two unknowns. That makes it solvable. Say we subtract the two equations, we can actually rearrange the equation to isolate k:

$$s_1-s_2=modinv(k, q)\cdot(H(msg_1)+x\cdot r-H(msg_2)+x\cdot r))\mod{q}$$
$$s_1-s_2=modinv(k, q)\cdot(H(msg_1)-H(msg_2)))\mod{q}$$
$$k\cdot(s_1-s_2)=(H(msg_1)-H(msg_2)))\mod{q}$$
$$k=modinv(s_1 - s_2, q)\cdot(H(msg_1)-H(msg_2)))\mod{q}$$

Now that k is isolated, we can simply calculate it. In order to forge a signature, we also need to calculate x. Rearranging the original equation:

$$s_1=modinv(k, q)\cdot(H(msg_1)+x\cdot r)\mod{q}$$
$$s_1\cdot k\mod{q}=(H(msg_1)+x\cdot r)\mod{q}$$
$$(s_1\cdot k\mod{q}-H(msg_1))=x\cdot r\mod{q}$$
$$x=(s_1\cdot k\mod{q}-H(msg_1))\cdot modinv(r, q)$$

Thus, we can also calculate x. We now have the means to forge a signature for any message we want. These equations are taken from [this](https://ctftime.org/writeup/19928) writeup of a very similar challenge.

---

### Solution

Based on this exploit, I came up with the following solve script:

```python
from Crypto.Util.number import bytes_to_long
from hashlib import sha256
import os

from pwn import *
import string


def H(s):
    return int(sha256(s.encode()).hexdigest(), 16)


def sign_message(msg):
    while True:
        # Choose random nonce and check signature validity
        k = bytes_to_long(os.urandom(2))
        r = pow(g, k, p) % q
        s = (pow(k, -1, q) * (H(msg) + x * r)) % q
        if r > 1 and s > 0:
            return r, s


def generate_signature(msg):
	conn.recvuntil(b">")
	conn.sendline(b"1")
	
	conn.recvuntil(b">")
	conn.sendline(msg.encode())
	
	conn.recvuntil(b"Signature:")
	sig = conn.recvline()[:-1].decode()
	sig = sig.replace("(", "").replace(")", "")
	r, s = sig.split(", ")
	
	r = int(r)
	s = int(s)
	
	return r, s


def crack(r, s1, s2, msg1, msg2):
	k = (H(msg1) - H(msg2)) * pow(s1 - s2, -1, q) % q  # Calculate k from two signatures
	x = (s1 * k % q - H(msg1)) * pow(r, -1, q) % q  # Calculate private x from k and signature
	
	return k, x


# conn = process(["python3", "server.py"])
conn = connect("dsa.hkn", 1337)

conn.recvuntil(b"(p, q, g, y) = ")
params = conn.recvline()[:-1].decode()
params = params.replace("(", "").replace(")", "")
p, q, g, y = (int(v) for v in params.split(", "))

sigs = {}

while True:  # Generate signatures until we have a collision
	msg = "".join(random.sample(string.ascii_lowercase, 5))  # Random message so signatures are different
	r, s = generate_signature(msg)

	if r in sigs:  # Check if we have a collision
		break
		
	sigs[r] = (s, msg)


k, x = crack(r, sigs[r][0], s, sigs[r][1], msg)  # Calculate k and x
r, s = sign_message("CONFIDENTIAL")  # Forge signature for CONFIDENTIAL

conn.recvuntil(b">")
conn.sendline(b"2")

conn.recvuntil(b">")
conn.sendline(b"CONFIDENTIAL")

conn.recvuntil(b">")
conn.sendline(f"({r}, {s})".encode())  # Verify the forged signature

conn.interactive()
```

It takes a while to do on remote, but it will eventually get there, as the probability of collision continuously rises.