#!/usr/bin/env python3

import os
from Crypto.PublicKey import DSA
from Crypto.Util.number import bytes_to_long
from hashlib import sha256

from secret import codeword, flag


# Generate DSA parameters - https://en.wikipedia.org/wiki/Digital_Signature_Algorithm#1._Key_generation
key = DSA.generate(1024)
p = key.p
q = key.q
g = key.g
x = key.x  # Private key
y = key.y  # Public key


def H(s):
    return int(sha256(s.encode()).hexdigest(), 16)


def sign_message(msg):
    while True:
        # Choose random nonce and check signature validity
        k = bytes_to_long(os.urandom(2))
        r = pow(g, k, p) % q
        s = (pow(k, -1, q) * (H(msg) + x * r)) % q
        if r > 1 and s > 0:
            return r, s


def verify_message(msg, r, s):
    # Verify the message signature
    w = pow(s, -1, q)
    u1 = (H(msg) * w) % q
    u2 = (r * w) % q
    v = ((pow(g, u1, p) * pow(y, u2, p)) % p) % q
    return v == r


def get_input(prompt):
    print(prompt)
    inp = input("> ")
    print()
    return inp


# Handle incoming ections
def main():
    print("== DIGITAL SECRET AGENCY ==")
    print("   Secret Mission Server\n")

    print("Public DSA params for manual verification:")
    print(f"{(p, q, g, y) = }\n")

    # Loop until user quits
    while True:
        choice = get_input("1. Sign new mission statement\n2. Verify mission statement\n3. Quit")

        # Sign (potentially confidential) mission statement
        if choice == "1":
            msg = get_input("Enter mission statement")
            if msg.startswith("CONFIDENTIAL"):
                print("Only leaders with a high security clearance can sign CONFIDENTIAL mission statements.")
                user_codeword = get_input("Verify your clearance with your secret codeword")
                if user_codeword != codeword:
                    print("This incidence has been logged, expect a visit soon\n")
                    continue
                print("Codeword verified, mission safe to sign\n")

            signature = sign_message(msg)
            print(f"Signature: {signature}\n")

        # Verify mission statement
        elif choice == "2":
            msg = get_input("Enter mission statement to verify")
            signature = get_input("Enter received signature (r,s)").replace("(", "").replace(")", "").split(",")
            try:
                r = int(signature[0])
                s = int(signature[1])
            except:
                print("Invalid signature format\n")
                continue

            valid = verify_message(msg, r, s)
            if valid:
                print("Mission statement verified")

                # Give agents needed codeword for confidential missions
                if msg.startswith("CONFIDENTIAL"):
                    print(f"Codeword: {flag}")

                print("Good luck, agent!\n")
            else:
                print("Invalid signature! Be careful, agent!\n")

        # Exit
        elif choice == "3":
            print("Goodbye, agent - good luck!")
            break

        else:
            print("Invalid choice")


if __name__ == "__main__":
    main()
